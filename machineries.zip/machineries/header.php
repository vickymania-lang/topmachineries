<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <title>Top Machineries</title>
	<link rel="canonical" href="https://duruthemes.com" />
    <link rel="shortcut icon" href="<?php echo $DOT;?>img/favicon.png" />
    <link rel="stylesheet" href="<?php echo $DOT;?>css/plugins.css" />
    <link rel="stylesheet" href="//fonts.googleapis.com/css2?family=Didact+Gothic&family=Syne:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="<?php echo $DOT;?>css/style.css" />
</head>
<body>
    <!-- Preloader -->
    <div class="preloader-bg"></div>
    <div id="preloader">
        <div id="preloader-status">
            <div class="preloader-position loader"> <span></span> </div>
        </div>
    </div>
    <!-- Progress scroll totop -->
    <div class="progress-wrap">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
        </svg>
    </div>
    <!-- Top Navbar -->
    <div class="main-header">
        <div class="header-top">
            <div class="container">
                <div class="top-outer clearfix">
                    <!--Top Left-->
                    <div class="top-left">
                        <ul class="links clearfix">
                            <li><a href="tel:+12033334444"><span class="fa fa-phone"></span>+234 803-333-4456</a></li>
                            <li><a href="mailto:info@construction.com"><span class="fa fa-envelope"></span>info@topmachineries.com</a></li>
                            <li><a href="https://goo.gl/maps/zgdqkg4hFFR8pfDS8" target="_blank"><span class="fa fa-map-marker"></span>24 King St, SC 29401 China</a></li>
                        </ul>
                    </div>
                    <!--Top Right-->
                    <div class="top-right clearfix">
                        <ul class="social-icon-one">
                            <li>
                                <a href="#" class="fa fa-whatsapp"></a>
                            </li>
                            <li>
                                <a href="#" class="fa fa-twitter"></a>
                            </li>
                            <li>
                                <a href="#" class="fa fa-instagram"></a>
                            </li>
                            <li>
                                <a href="#" class="fa fa-youtube-play"></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-md">
        <div class="container">
            <!-- Logo -->
            <a class="logo" href="<?php echo $DOT;?>"> <img src="<?php echo $DOT;?>images/high-weigh-logo.png" alt=""> </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar" aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"><i class="fa fa-bars"></i></span> </button>
            <!-- Navbar links -->
            <div class="collapse navbar-collapse" id="navbar">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link <?php if ($page=="home") {echo "active"; } else  {echo "noactive";}?>" href="<?php echo $DOT;?>">Home</a></li>
                    <li class="nav-item"><a class="nav-link <?php if ($page=="about") {echo "active"; } else  {echo "noactive";}?>" href="<?php echo $DOT;?>about/">About</a></li>
                    <li class="nav-item"><a class="nav-link <?php if ($page=="services") {echo "active"; } else  {echo "noactive";}?>" href="<?php echo $DOT;?>services/">Services</a></li>
                    <li class="nav-item"><a class="nav-link <?php if ($page=="products") {echo "active"; } else  {echo "noactive";}?>" href="<?php echo $DOT;?>products/">Products</a></li>
                    <li class="nav-item"><a class="nav-link <?php if ($page=="contact") {echo "active"; } else  {echo "noactive";}?>" href="<?php echo $DOT;?>contact/">Contact</a></li>
                </ul>
            </div>
        </div>
    </nav>



