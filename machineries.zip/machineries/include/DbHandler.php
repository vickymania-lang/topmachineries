<?php
	    use PHPMailer\PHPMailer\PHPMailer;
        use PHPMailer\PHPMailer\Exception;

/**
 * Class to handle all db operations
 * This class will have CRUD methods for database tables
 *
 * @author
 * @link URL Tutorial link
 */
class DbHandler {

	private $conn;
	private $hasher;

	private $USER = "user";
	private $BLOG = "blogs";
	private $BLOGCATEGORY = "blog_category";
	private $SUBSCRIPTION = "subscription";
	private $TRAINING = "training";
	private $PAYMENTS = "payment";
	private $BANNER = "banner";
	private $SETTINGS = "settings";
	private $COMMENTS = "comments";
	private $BOOKS = "books";
	private $OTP = "otp";
	private $REQUESTS = "requests";
	private $PRODUCTS = "products";

	private $no_of_records_per_page = 10;

    private $supportemailPassword = "1@KHDxCt@9E^";
	private $supportemail = "beeba@mixandshakesbybeeba.com"; //password: 1@KHDxCt@9E^
	private $beebamail = "Beebaluv28@gmail.com";

    public function __construct() {
		require_once dirname(__FILE__) . '/DbConnect.php';
		require_once dirname(__FILE__) . '/class-phpass.php';
        // opening db connection
        $db = new DbConnect();
		$this->conn = $db->connect();
		$this->hasher = new PasswordHash( 8, true );
	}

	// destructor
    function __destruct() {
        $this->conn->close();
	}

	public function getProducts(){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = array();
		$sql = "select * from $this->PRODUCTS";
		
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			array_push($response, array('title'=> $row['title'], 'price'=> $row['price'], 'image' => $row['images']));
			unset($row);
		}
		$result->close();
		unset($sql);
		return $response;
	}

	/*
	check if password match
	*/
	public function checkPassword($password, $stored_hash){
		return $this->hasher->CheckPassword($password, $stored_hash);
	}

	public function addForgotpassword($email, $token, $toexpire){
		$sql = "INSERT INTO $this->FORGOTPASSWORD (email, token, toexpire) VALUES(?, ?, ?)";
		$stmt = $this->conn->prepare($sql);
		$stmt->bind_param("sss", $email, $token, $toexpire);
		$result = $stmt->execute();
		$lastid = $this->conn->insert_id;
		$stmt->close();
		return $lastid;
	}

	public function addUser($email, $password, $token, $fullname, $instagram, $whatsapp, $allergies){
		require_once 'PassHash.php';
		$hash = PassHash::hash($password);
		$sql = "INSERT INTO $this->USER (email, password_hash, token, full_names, instagram, whatsapp, allergies) VALUES(?, ?, ?, ?, ?, ?, ?)";
		$stmt = $this->conn->prepare($sql);
		$stmt->bind_param("sssssss", $email, $hash, $token, $fullname, $instagram, $whatsapp, $allergies);
		$result = $stmt->execute();
		$lastid = $this->conn->insert_id;
		$stmt->close();
		//$this->sendWelcomeMail($email, $password, $firstname);
		return $lastid;
	}

	public function isUserExist($email, $whatsapp, $instagram) {
        // $stmt = $this->conn->prepare("SELECT * from $this->USER WHERE email = ? OR whatsapp = ? OR instagram = ?");
        // $stmt->bind_param("sss", $email, $whatsapp, $instagram);
        
        $stmt = $this->conn->prepare("SELECT * from $this->USER WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
	}

	public function isUser($email, $whatsapp, $instagram) {
        $stmt = $this->conn->prepare("SELECT * from $this->USER WHERE email = ? OR whatsapp = ? OR instagram = ?");
        $stmt->bind_param("sss", $email, $whatsapp, $instagram);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
	}

	public function generateUserToken(){
		//Generate a random string.
		$token = openssl_random_pseudo_bytes(16);
		
		// //Convert the binary data into hexadecimal representation.
		$token = bin2hex($token);
		//$token = "dlklfkdfldk";
		
		//Print it out for example purposes.
		return $token;
	}

	public function generateTransactionReference(){
		//Generate a random string.
		$token = openssl_random_pseudo_bytes(10);
		// //Convert the binary data into hexadecimal representation.
		$token = bin2hex($token);
		//$token = "dlklfkdfldk";
		//Print it out for example purposes.
		return $token;
	}
	
	public function deleteSubscriber($id){
		//check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$sql = "delete from $this->SUBSCRIPTION where id = ?";
		$stmt = $this->conn->prepare($sql);
		$stmt->bind_param("i", $id);
		$result = $stmt->execute();
		$stmt->close();
		//$result->close();
		return $result;
	}

	public function getSubscriptionStatus($token){
		$status = $this->isSubscribed($token);
		
		if($status){
			$subscriptionData = $this->getSubscriptionDates($token);
			$today = date("Y-m-d H:i:s");
			//$date = new DateTime($today);
			$start = $subscriptionData['start'];
			$end = $subscriptionData['end'];

			$startDatedt = strtotime($start);
			$endDatedt = strtotime($end);
			$usrDatedt = strtotime($today);
			
				// 		print_r("<br/>");
                //             		print_r("<br/>");
                //             		print_r("<br/>");
                //             		print_r("<br/>");
                //             		print_r("today: $usrDatedt");
                //             		print_r("start: $startDatedt");
                //             		print_r("end: $endDatedt");

			if( $usrDatedt >= $startDatedt && $usrDatedt <= $endDatedt)
			{

				return true;
			}else{

				return false;
			}
		}else{
			return false;
		}
	}

	public function getSubscriptionDates($token){
		$response = array();
		$sql = "SELECT * FROM $this->SUBSCRIPTION where token = '$token'";
		$result = $this->conn->query($sql);
		$rowcount = mysqli_num_rows($result);
		
		while($row = $result->fetch_array()){
			$id = $row['id'];
			$start = $row['start_date'];
			$token = $row['token'];
			$end = $row['end_date'];
			$amount = $row['amount'];

			$response[] = array('id' => $id, 'start'=> $start, 'end'=> $end, 'amount' => $amount);	
		}
		return $response[0];
	}

	public function isSubscribed($token) {
        $stmt = $this->conn->prepare("SELECT * from $this->SUBSCRIPTION WHERE token = ?");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
	}
	
	public function isSubscriber($id) {
        $stmt = $this->conn->prepare("SELECT * from $this->SUBSCRIPTION WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
	}

	public function deleteTrainee($id){
		//check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$sql = "delete from $this->TRAINING where id = ?";
		$stmt = $this->conn->prepare($sql);
		$stmt->bind_param("i", $id);
		$result = $stmt->execute();
		$stmt->close();
		//$result->close();
		return $result;
	}

	public function getTrainingStatus($token){
		$status = $this->isTrained($token);
		
		if($status){
			$subscriptionData = $this->getTrainingDates($token);
			$today = date("Y-m-d H:i:s");
			//$date = new DateTime($today);
			$start = $subscriptionData['start'];
			$end = $subscriptionData['end'];

			$startDatedt = strtotime($start);
			$endDatedt = strtotime($end);
			$usrDatedt = strtotime($today);
			
				// 		print_r("<br/>");
                //             		print_r("<br/>");
                //             		print_r("<br/>");
                //             		print_r("<br/>");
                //             		print_r("today: $usrDatedt");
                //             		print_r("start: $startDatedt");
                //             		print_r("end: $endDatedt");

			if( $usrDatedt >= $startDatedt && $usrDatedt <= $endDatedt)
			{

				return true;
			}else{

				return false;
			}
		}else{
			return false;
		}
	}

	public function getTrainingDates($token){
		$response = array();
		$sql = "SELECT * FROM $this->TRAINING where token = '$token'";
		$result = $this->conn->query($sql);
		$rowcount = mysqli_num_rows($result);
		
		while($row = $result->fetch_array()){
			$id = $row['id'];
			$start = $row['start_date'];
			$token = $row['token'];
			$end = $row['end_date'];
			$amount = $row['amount'];

			$response[] = array('id' => $id, 'start'=> $start, 'end'=> $end, 'amount' => $amount);	
		}
		return $response[0];
	}

	public function isTrained($token) {
        $stmt = $this->conn->prepare("SELECT * from $this->TRAINING WHERE token = ?");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
	}
	
	public function isTrainee($id) {
        $stmt = $this->conn->prepare("SELECT * from $this->TRAINING WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
	}

	public function isDateBetweenDates(DateTime $date, DateTime $startDate, DateTime $endDate) {
		return $date > $startDate && $date < $endDate;
	}

	public function isComment($bid) {
        $stmt = $this->conn->prepare("SELECT * from $this->COMMENTS WHERE bid = ?");
        $stmt->bind_param("i", $bid);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
	}

	public function addComments($bid, $description, $name){
		$sql = "INSERT INTO $this->COMMENTS (bid, description, name) VALUES(?, ?, ?)";
		$stmt = $this->conn->prepare($sql);
		$stmt->bind_param("iss", $bid, $description, $name);
		$result = $stmt->execute();
		$lastid = $this->conn->insert_id;
		$stmt->close();
	}

	public function getComments($bid){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = array();
		$sql = "select * from $this->COMMENTS where bid = $bid";
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$publishdate = date_create($row['date']);
			$date = date_format($publishdate,"Y-m-d h:i:s");
			array_push($response, array('id'=> $row['id'], 'description'=> $row['description'], 'name' => $row['name'], 'date' => $date));
			unset($row);
		}
		$result->close();
		unset($sql);
		return $response;
	}

	public function addBlogCategory($category){
		$sql = "INSERT INTO $this->BLOGCATEGORY (category) VALUES(?)";
		$stmt = $this->conn->prepare($sql);
		$stmt->bind_param("s", $category);
		$result = $stmt->execute();
		$lastid = $this->conn->insert_id;
		$stmt->close();
	}

	public function addBlog($title, $coverimage, $description, $preview, $category){
		$sql = "INSERT INTO $this->BLOG (title, cover_image, description, preview, blog_category_fk) VALUES(?, ?, ?, ?, ?)";
		$stmt = $this->conn->prepare($sql);
		$stmt->bind_param("ssssi", $title, $coverimage, $description, $preview, $category);
		$result = $stmt->execute();
		$lastid = $this->conn->insert_id;
		$stmt->close();
		//$this->sendWelcomeMail($email, $password, $firstname);
		return $lastid;
	}

// 	public function updateBlog($id, $title, $coverImage, $description, $preview, $category){
// 		$sql = "UPDATE $this->BLOG SET title = ?, cover_image = ?, description = ? , preview = ?, blog_category_fk = ?  WHERE id = ?";
// 		//print_r($sql2);
// 		$stmt = $this->conn->prepare($sql);
// 		$stmt->bind_param("ssssii", $title, $coverImage, $description, $preview, $category, $id);
// 		$result = $stmt->execute();
// 		$lastid = $this->conn->insert_id;
// 		$stmt->close();
// 		return $lastid;
// 	}
    public function updateBlog($id, $title, $coverImage, $description, $preview, $category){
		$sql = "UPDATE $this->BLOG SET title = '$title', cover_image = '$coverImage', description = '$description' , preview = '$preview', blog_category_fk = $category  WHERE id = $id";
		//print_r($sql);
		if ($this->conn->query($sql) === TRUE){
			unset($sql);
			return true;
		}else{
			unset($sql);
			return false;
		}
	}
	
	
	public function addBook($location){
		$sql = "INSERT INTO $this->BOOKS (location) VALUES(?)";
		$stmt = $this->conn->prepare($sql);
		$stmt->bind_param("s", $location);
		$result = $stmt->execute();
		$lastid = $this->conn->insert_id;
		$stmt->close();
		//$this->sendWelcomeMail($email, $password, $firstname);
		return $lastid;
	}

	public function updateBook($id, $title, $author, $coverImage, $description){
		$sql = "UPDATE $this->BOOKS SET title = ?, cover = ?, author =?, description = ? WHERE id = ?";
		//print_r($sql2);
		$stmt = $this->conn->prepare($sql);
		$stmt->bind_param("ssssi", $title, $coverImage, $author, $description, $id);
		$result = $stmt->execute();
		$lastid = $this->conn->insert_id;
		$stmt->close();
		return $lastid;
	}

	public function deleteBook($id){
		//check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$sql = "delete from $this->BOOKS where id = ?";
		$stmt = $this->conn->prepare($sql);
		$stmt->bind_param("i", $id);
		$result = $stmt->execute();
		$stmt->close();
		//$result->close();
		return $result;
	}

	public function isBook($id) {
		$sql ="SELECT * from $this->BOOKS WHERE id = $id ";
        $result = $this->conn->query($sql);
		$rowcount = mysqli_num_rows($result);
		if($rowcount <= 0){
			return false;
		}
		return true;
	}

	public function getBookById($id){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = array();
		$sql = "select * from $this->BOOKS where id = $id";
		
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$publishdate = date_create($row['date']);
			$date = date_format($publishdate,"d M, Y");
			array_push($response, array('id'=> $row['id'], 'title'=> $row['title'],'description' => $row['description'], 'location' => $row['location'], 'cover' => $row['cover'],'author' => $row['author'],'date' => $date));
			unset($row);
		}
		$sql="SELECT FOUND_ROWS()";
		$result = $this->conn->query($sql);
		$total = $result->num_rows; 
		$result->close();
		unset($sql);
		return array('data' =>$response, 'total' => $total);
	}

	public function getBookItems(){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = array();
		$sql = "select * from $this->BOOKS";
		
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$publishdate = date_create($row['date']);
			$date = date_format($publishdate,"d M, Y");
			array_push($response, array('id'=> $row['id'], 'title'=> $row['title'],'description' => $row['description'], 'location' => $row['location'], 'cover' => $row['cover'],'author' => $row['author'],'date' => $date));
			unset($row);
		}
		$sql="SELECT FOUND_ROWS()";
		$result = $this->conn->query($sql);
		$total = $result->num_rows; 
		$result->close();
		unset($sql);
		return array('data' =>$response, 'total' => $total);
	}

	public function getBooks($query){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}

		$response = array();
		$sql = "select SQL_CALC_FOUND_ROWS * from $this->BOOKS where  MATCH (title) AGAINST ('$query' IN NATURAL LANGUAGE MODE)";
		//print_r("<br><br><br>".$sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$publishdate = date_create($row['date']);
			$date = date_format($publishdate,"d M, Y");
			array_push($response, array('id'=> $row['id'], 'title'=> $row['title'],'description' => $row['description'], 'location' => $row['location'], 'cover' => $row['cover'],'author' => $row['author'],'date' => $date));
			unset($row);
		}
		$sql="SELECT FOUND_ROWS()";
		$result = $this->conn->query($sql);
		$total = $result->num_rows; 
		$result->close();
		unset($sql);
		return array('data' =>$response, 'total' => $total);
	}
	

	public function isBanner($id) {
		$sql ="SELECT * from $this->BANNER WHERE id = $id ";
        $result = $this->conn->query($sql);
		$rowcount = mysqli_num_rows($result);
		if($rowcount <= 0){
			return false;
		}
		return true;
	}

	public function updateBanner($id, $coverImage, $description){
		$sql = "UPDATE $this->BANNER SET image = ?, description = ? WHERE id = ?";
		$stmt = $this->conn->prepare($sql);
		$stmt->bind_param("ssi", $coverImage, $description, $id);
		$result = $stmt->execute();
		$lastid = $this->conn->insert_id;
		$stmt->close();
		return $lastid;
	}

	public function getBanner(){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = array();
		$sql = "select * from $this->BANNER";
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			array_push($response, array('id'=> $row['id'], 'image'=> $row['image'],'description' => $row['description']));
			unset($row);
		}
		$result->close();
		unset($sql);
		return $response;
	}


	public function getSettings(){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = array();
		$sql = "select * from $this->SETTINGS";
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			array_push($response, array('id'=> $row['id'], 'name'=> $row['name'],'value' => $row['value']));
			unset($row);
		}
		$result->close();
		unset($sql);
		return $response;
	}

	public function getSettingsData(){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = array();
		$sql = "select * from $this->SETTINGS";
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$response[$row['name']] = $row['value'];
			//array_push($response, array('id'=> $row['id'], 'name'=> $row['name'],'value' => $row['value']));
			unset($row);
		}
		$result->close();
		unset($sql);
		return $response;
	}


	public function updateSettings($name, $value){
		$sql = "UPDATE $this->SETTINGS SET value = ? WHERE name = ?";
		$stmt = $this->conn->prepare($sql);
		$stmt->bind_param("ss", $value, $name);
		$result = $stmt->execute();
		$lastid = $this->conn->insert_id;
		$stmt->close();
		return $lastid;
	}

	public function getSubscriptionAmount(){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = 0.00;
		$sql = "select * from $this->SETTINGS where name = 'subscription_amount'";
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$response = $row['value'];
			unset($row);
		}
		$result->close();
		unset($sql);
		return $response;
	}

	public function getTrainingAmount(){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = 0.00;
		$sql = "select * from $this->SETTINGS where name = 'training_amount'";
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$response = $row['value'];
			unset($row);
		}
		$result->close();
		unset($sql);
		return $response;
	}

	public function getSubscriptionDuration(){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = 0.00;
		$sql = "select * from $this->SETTINGS where name = 'subscription_duration'";
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$response = $row['value'];
			unset($row);
		}
		$result->close();
		unset($sql);
		return $response;
	}

	public function getTrainingDuration(){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = 0.00;
		$sql = "select * from $this->SETTINGS where name = 'training_duration'";
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$response = $row['value'];
			unset($row);
		}
		$result->close();
		unset($sql);
		return $response;
	}
	

	public function getPaystack(){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = '';
		$sql = "select * from $this->SETTINGS where name = 'paystack'";
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$response = $row['value'];
			unset($row);
		}
		$result->close();
		unset($sql);
		return $response;
	}

    public function getRecipeBanner(){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = '';
		$sql = "select * from $this->SETTINGS where name = 'recipe_banner'";
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$response = $row['value'];
			unset($row);
		}
		$result->close();
		unset($sql);
		return 'banners/'.$response;
	}
	
	public function getAbout(){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = '';
		$sql = "select * from $this->SETTINGS where name = 'about'";
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$response = $row['value'];
			unset($row);
		}
		$result->close();
		unset($sql);
		return $response;
	}
	
	public function getWelcome(){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = '';
		$sql = "select * from $this->SETTINGS where name = 'welcome'";
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$response = $row['value'];
			unset($row);
		}
		$result->close();
		unset($sql);
		return $response;
	}
	
	public function getMyself(){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = '';
		$sql = "select * from $this->SETTINGS where name = 'myself'";
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$response = $row['value'];
			unset($row);
		}
		$result->close();
		unset($sql);
		return $response;
	}

	public function deleteBlog($id){
		//check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$sql = "delete from $this->BLOG where id = ?";
		$stmt = $this->conn->prepare($sql);
		$stmt->bind_param("i", $id);
		$result = $stmt->execute();
		$stmt->close();
		//$result->close();
		return $result;
	}
	
	public function getBlogTitleById($id){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = '';
		$sql = "select * from $this->BLOG where id = $id";
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$response = $row['title'];
			unset($row);
		}
		$result->close();
		unset($sql);
		return $response;
	}

	public function getBlogById($id){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = array();
		$sql = "select * from $this->BLOG where id = $id";
		
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$publishdate = date_create($row['date']);
			$date = date_format($publishdate,"d M, Y");
			array_push($response, array('id'=> $row['id'], 'title'=> $row['title'],'description' => $row['description'], 'preview' => $row['preview'], 'cover' => $row['cover_image'],'category' => $row['blog_category_fk'],'date' => $date));
			unset($row);
		}
		$sql="SELECT FOUND_ROWS()";
		$result = $this->conn->query($sql);
		$total = $result->num_rows; 
		$result->close();
		unset($sql);
		return array('data' =>$response, 'total' => $total);
	}

	public function getBlogsItems(){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = array();
		$sql = "select * from $this->BLOG";
		
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$publishdate = date_create($row['date']);
			$date = date_format($publishdate,"d M, Y");
			array_push($response, array('id'=> $row['id'], 'title'=> $row['title'],'description' => $row['description'], 'preview' => $row['preview'], 'cover' => 'uploads/'.$row['cover_image'],'category' => $row['blog_category_fk'],'date' => $date));
			unset($row);
		}
		$sql="SELECT FOUND_ROWS()";
		$result = $this->conn->query($sql);
		$total = $result->num_rows; 
		$result->close();
		unset($sql);
		return array('data' =>$response, 'total' => $total);
	}

	public function getBlog($category){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = array();
		$sql = "";
		if(empty($category) || $category === "All" || $category === "all")
			$sql = "select SQL_CALC_FOUND_ROWS b.id as id, b.title as title,  b.preview as preview, b.description as description, b.cover_image as cover, b.date as date, ca.category as category from $this->BLOG b INNER JOIN $this->BLOGCATEGORY ca ON b.blog_category_fk = ca.id";
		else{
			$sql = "select SQL_CALC_FOUND_ROWS b.id as id, b.title as title,  b.preview as preview, b.description as description, b.cover_image as cover, b.date as date, ca.category as category from $this->BLOG b INNER JOIN $this->BLOGCATEGORY ca ON b.blog_category_fk = ca.id where ca.category = '$category'";
		}
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$publishdate = date_create($row['date']);
			$date = date_format($publishdate,"d M, Y");
			array_push($response, array('id'=> $row['id'], 'title'=> $row['title'],'description' => $row['description'], 'preview' => $row['preview'], 'cover' => 'uploads/'.$row['cover'],'category' => $row['category'],'date' => $date));
			unset($row);
		}
		$sql="SELECT FOUND_ROWS()";
		$result = $this->conn->query($sql);
		$total = $result->num_rows; 
		$result->close();
		unset($sql);
		return array('data' =>$response, 'total' => $total);
	}

	public function getBlogs($query){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}

		$response = array();
		$sql = "select SQL_CALC_FOUND_ROWS b.id as id, b.title as title, b.description as description, b.cover_image as cover, b.date as date, ca.category as category from $this->BLOG b INNER JOIN $this->BLOGCATEGORY ca ON b.blog_category_fk = ca.id where  MATCH (b.title) AGAINST ('$query' IN NATURAL LANGUAGE MODE)";
		//print_r("<br><br><br>".$sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$publishdate = date_create($row['date']);
			$date = date_format($publishdate,"d M, Y");
			array_push($response, array('id'=> $row['id'], 'title'=> $row['title'], 'preview' => $row['preview'],'cover' => 'uploads/'.$row['cover'],'category' => $row['category'],'date' => $date));
			unset($row);
		}
		$sql="SELECT FOUND_ROWS()";
		$result = $this->conn->query($sql);
		$total = $result->num_rows; 
		$result->close();
		unset($sql);
		return array('data' =>$response, 'total' => $total);
	}

	public function isBlog($category, $title) {
        $sql ="SELECT * from $this->BLOG WHERE title = '$title' and blog_category_fk = $category ";
        $result = $this->conn->query($sql);
		$rowcount = mysqli_num_rows($result);
		
		if($rowcount <= 0){
			return false;
		}
		return true;
	}

	public function isBlogId($id) {
		$sql ="SELECT * from $this->BLOG WHERE id = $id ";
        $result = $this->conn->query($sql);
		$rowcount = mysqli_num_rows($result);
		if($rowcount <= 0){
			return false;
		}
		return true;
	}

	public function isSubscription($token) {
		$sql ="SELECT * from $this->SUBSCRIPTION WHERE token = '$token' ";
        $result = $this->conn->query($sql);
		$rowcount = mysqli_num_rows($result);
		if($rowcount <= 0){
			return false;
		}
		return true;
	}

	public function isTraining($token) {
		$sql ="SELECT * from $this->TRAINING WHERE token = '$token' ";
        $result = $this->conn->query($sql);
		$rowcount = mysqli_num_rows($result);
		if($rowcount <= 0){
			return false;
		}
		return true;
	}

    public function isPayment($transactionid) {
		$sql ="SELECT * from $this->PAYMENTS WHERE transaction_id = '$transactionid' ";
        $result = $this->conn->query($sql);
		$rowcount = mysqli_num_rows($result);
		if($rowcount <= 0){
			return false;
		}
		return true;
	}
	
	public function addSubscription($token, $start_date, $end_date, $amount){
		$sql = "INSERT INTO $this->SUBSCRIPTION (token, start_date, end_date, amount) VALUES(?, ?, ?, ?)";

		$stmt = $this->conn->prepare($sql);
		$stmt->bind_param("sssd", $token, $start_date, $end_date, $amount);
		$result = $stmt->execute();
		$lastid = $this->conn->insert_id;
		$stmt->close();
	}

	public function addTraining($token, $start_date, $end_date, $amount){
		$sql = "INSERT INTO $this->TRAINING (token, start_date, end_date, amount) VALUES(?, ?, ?, ?)";

		$stmt = $this->conn->prepare($sql);
		$stmt->bind_param("sssd", $token, $start_date, $end_date, $amount);
		$result = $stmt->execute();
		$lastid = $this->conn->insert_id;
		$stmt->close();
	}

	public function updateSubscription($token, $start_date, $end_date, $amount){
		$sql = "UPDATE $this->SUBSCRIPTION SET start_date = ?, end_date = ?, amount = ? WHERE token = ?";
		$stmt = $this->conn->prepare($sql);
		$stmt->bind_param("ssds", $start_date, $end_date, $amount, $token);
		$result = $stmt->execute();
		$lastid = $this->conn->insert_id;
		$stmt->close();
		return $lastid;
	}

	public function updateTraining($token, $start_date, $end_date, $amount){
		$sql = "UPDATE $this->TRAINING SET start_date = ?, end_date = ?, amount = ? WHERE token = ?";
		$stmt = $this->conn->prepare($sql);
		$stmt->bind_param("ssds", $start_date, $end_date, $amount, $token);
		$result = $stmt->execute();
		$lastid = $this->conn->insert_id;
		$stmt->close();
		return $lastid;
	}

	public function addPayment($uid, $token, $amount, $transactionid){
		$sql = "INSERT INTO $this->PAYMENTS (uid, token, amount, transaction_id) VALUES(?, ?, ?, ?)";
		$stmt = $this->conn->prepare($sql);
		$stmt->bind_param("isds", $uid, $token, $amount, $transactionid);
		$result = $stmt->execute();
		$lastid = $this->conn->insert_id;
		$stmt->close();
	}
	
	public function updatePayment($uid, $token, $amount, $transactionid){
		$sql = "UPDATE $this->PAYMENTS SET uid = ?, amount = ?, transaction_id = ? WHERE token = ?";
		$stmt = $this->conn->prepare($sql);
		$stmt->bind_param("idss", $uid, $amount, $transactionid, $token);
		$result = $stmt->execute();
		$lastid = $this->conn->insert_id;
		$stmt->close();
	}
	
	public function sendEmailOnContactUs($name, $email, $phone, $message){
	    $emailtitle = "Inquiry From Beeba Customer";
		$emailbody = "<h5>From $name</h5><h6>$phone - $email</h6><p>$message</p>";
		$emailuser = $this->beebamail;
		$emailsender = "Mix and Shakes By Beeba";
		$emailmessage = $this->getEmailTemplate($emailbody);
		//print_r("send otp mail");
		$this->sendEmail($emailtitle, $emailmessage, $emailuser, $this->supportemail);
	}
	
	public function sendEmailOnComment($name, $title, $message){
	    $emailtitle = "Comment From Beeba Customer";
		$emailbody = "<h5>From $name</h5><h6> on $title </h6><p>$message</p>";
		$emailuser = $this->beebamail;
		$emailsender = "Mix and Shakes By Beeba";
		$emailmessage = $this->getEmailTemplate($emailbody);
		//print_r("send otp mail");
		$this->sendEmail($emailtitle, $emailmessage, $emailuser, $this->supportemail);
	}

    public function addRequests($email, $title, $description){
		$sql = "INSERT INTO $this->REQUESTS (email, title, description) VALUES(?, ?, ?)";
		$stmt = $this->conn->prepare($sql);
		$stmt->bind_param("sss", $email, $title, $description);
		$result = $stmt->execute();
		$lastid = $this->conn->insert_id;
		$stmt->close();
		//send an email to confirm request receipt
		$this->sendRequestMail($email, $title);
	}

	public function sendRequestMail($email, $title){
		$emailtitle = "Recipe Request Acknowledged";
		$emailbody = "Hi $email, I have received your request ($title). I would get back to you soonest on it. Meanwhile continue to check <a href='http://mixandshakesbybeeba.com'>my site </a> to keep yourself abreast of different mocktails and shakes";
		$emailuser = $email;
		$emailsender = "Mix and Shakes By Beeba";
		$emailmessage = $this->getEmailTemplate($emailbody);
		//print_r("send otp mail");
		$this->sendEmail($emailtitle, $emailmessage, $emailuser, $this->supportemail);
	}

	public function isRequests($id){
        $stmt = $this->conn->prepare("SELECT * from $this->REQUESTS WHERE id = ? ");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
	}

	public function updateRequests($id){
		$marked = 1;
		$sql = "UPDATE $this->REQUESTS SET marked = ? WHERE id = ?";
		$stmt = $this->conn->prepare($sql);
		$stmt->bind_param("ii", $marked, $id);
		$result = $stmt->execute();
		$lastid = $this->conn->insert_id;
		$stmt->close();
		return $lastid;
	}

	public function getRequests(){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = array();
		$sql = "select * from $this->REQUESTS";
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$publishdate = date_create($row['date']);
			$date = date_format($publishdate,"d M, Y");
			array_push($response, array('id'=> $row['id'], 'title'=> $row['title'],'description' => $row['description'], 'email' => $row['email'], 'marked' => $row['marked'], 'date' => $date));
			unset($row);
		}
		$result->close();
		unset($sql);
		return $response;
	}
	
		public function getRequestsById($id){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = array();
		$sql = "select * from $this->REQUESTS where id = $id";
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$publishdate = date_create($row['date']);
			$date = date_format($publishdate,"d M, Y");
			array_push($response, array('id'=> $row['id'], 'title'=> $row['title'],'description' => $row['description'], 'email' => $row['email'], 'marked' => $row['marked'], 'date' => $date));
			unset($row);
		}
		$result->close();
		unset($sql);
		return $response;
	}
	
	public function isUserToken($token){
        $stmt = $this->conn->prepare("SELECT * from $this->USER WHERE id = ? ");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
	}

	public function getUsersCount(){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = 0;
		$sql = "select count(*) as total from $this->USER";
		//print_r($sql);
		$result = $this->conn->query($sql);
		$row = $result->fetch_array();
		$response = (int)$row['total'];
		unset($row);
		$result->close();
		return $response;
	}

	public function getSubscriptionCount(){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = 0;
		$sql = "select count(*) as total from $this->SUBSCRIPTION";
		//print_r($sql);
		$result = $this->conn->query($sql);
		$row = $result->fetch_array();
		$response = (int)$row['total'];
		unset($row);
		$result->close();
		return $response;
	}

	public function getBlogCount(){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = 0;
		$sql = "select count(*) as total from $this->BLOG";
		//print_r($sql);
		$result = $this->conn->query($sql);
		$row = $result->fetch_array();
		$response = (int)$row['total'];
		unset($row);
		$result->close();
		return $response;
	}

	public function getTransactionVolume(){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = 0.0;
		$sql = "select * from $this->PAYMENTS";
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$amount = $row['amount'];
			$response = $response + $amount;
		}

		return $response;
	}

	public function isUserPassword($email, $password){
		require_once 'PassHash.php';
        $sql = "SELECT * from $this->USER WHERE email = '$email'";
        $result = $this->conn->query($sql);
		$rowcount = mysqli_num_rows($result);
		
		if($rowcount <= 0){
			return false;
		}
		$row = $result->fetch_array();
		if(PassHash::check_password($row['password_hash'], $password)){
			return true;
		}
		return false;
	}

	public function isAdminPassword($email, $password){
		require_once 'PassHash.php';
        $sql = "SELECT * from $this->USER WHERE email = 'admin'";
        $result = $this->conn->query($sql);
		$rowcount = mysqli_num_rows($result);
		
		if($rowcount <= 0){
			return false;
		}
		$row = $result->fetch_array();
		if(PassHash::check_password($row['password_hash'], $password)){
			return true;
		}
		return false;
	}

	public function isProject($projectId) {
        $stmt = $this->conn->prepare("SELECT * from $this->PROJECTS WHERE project_id = ? ");
        $stmt->bind_param("s", $projectId);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
	}

	public function isUserProject($userId, $projectId) {
        $stmt = $this->conn->prepare("SELECT * from $this->PROJECTS WHERE project_id = ? AND user_id = ?");
        $stmt->bind_param("ss", $projectId, $userId);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
	}

	public function getAllUsers(){
		$response = array();
		$sql = "SELECT * FROM $this->USER";
		$result = $this->conn->query($sql);
		$rowcount = mysqli_num_rows($result);
		
		while($row = $result->fetch_array()){
			$id = $row['id'];
			$email = $row['email'];
			$token = $row['token'];
			$fullname = $row['full_names'];
			$whatsapp = $row['whatsapp'];
			$instagram = $row['instagram'];
			$allergies = $row['allergies'];
			$date = $row['date'];

			$publishdate = date_create($row['date']);
			$date = date_format($publishdate,"d M, Y");
			
			if($email !== 'admin' && $email !== 'test@email.com')
			$response[] = array('id' => $id, 'email'=> $email, 'token'=> $token, 'full_names' => $fullname, 'whatsapp' => $whatsapp, 'instagram' => $instagram, 'date' => $date, 'allergies' => $allergies);	
		}
		return $response;
	}

	public function getAllTransactions(){
		$response = array();
		$sql = "SELECT u.email as email, p.transaction_id as transactionid, p.amount as amount, p.gateway as gateway, p.date as date FROM $this->PAYMENTS p INNER JOIN $this->USER u ON p.uid = u.id ";
		$result = $this->conn->query($sql);
		$rowcount = mysqli_num_rows($result);
		
		while($row = $result->fetch_array()){
			$id = $row['id'];
			$email = $row['email'];
			$transactionid = $row['transactionid'];
			$amount = $row['amount'];
			$gateway = $row['gateway'];
			$date = $row['date'];

			$publishdate = date_create($row['date']);
			$date = date_format($publishdate,"d M, Y");
			$response[] = array('id' => $id, 'email'=> $email, 'transactionid'=> $transactionid, 'amount' => $amount, 'gateway' => $gateway, 'date' => $date);	
		}
		return $response;
	}

	public function getAllSubscriptions(){
		$response = array();
		$sql = "SELECT u.full_names as full_names, u.email as email, p.amount as amount, p.start_date as start_date, p.end_date as end_date FROM $this->SUBSCRIPTION p INNER JOIN $this->USER u ON p.token = u.token ";
		$result = $this->conn->query($sql);
		$rowcount = mysqli_num_rows($result);
		
		while($row = $result->fetch_array()){
			$fullname = $row['full_names'];
			$email = $row['email'];
			$start_date = $row['start_date'];
			$amount = $row['amount'];
			$end_date = $row['end_date'];

			$publishdate = date_create($row['start_date']);
			$start_date = date_format($publishdate,"d M, Y");

			$publishdate = date_create($row['end_date']);
			$end_date = date_format($publishdate,"d M, Y");

			$response[] = array('fullnames' => $fullname, 'email'=> $email, 'amount' => $amount, 'start_date' => $start_date, 'end_date' => $end_date);	
		}
		return $response;
	}

    public function getUserUidByToken($token){
		// check connection
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$response = '-1';
		$sql = "select * from $this->USER where token = '$token'";
		//print_r($sql);
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$response = $row['id'];
			unset($row);
		}
		$result->close();
		unset($sql);
		return $response;
	}
	public function getUser($email){
		$response = array();
		$sql = "SELECT * FROM $this->USER where email = '$email'";
		$result = $this->conn->query($sql);
		$rowcount = mysqli_num_rows($result);
		
		if($rowcount <= 0){
			return false;
		}
		
		while($row = $result->fetch_array()){
			$id = $row['id'];
			$email = $row['email'];
			$token = $row['token'];
			$fullname = $row['full_names'];
			$whatsapp = $row['whatsapp'];
			$instagram = $row['instagram'];
			$date = $row['date'];

			$publishdate = date_create($row['date']);
			$date = date_format($publishdate,"d M, Y");

			$response[] = array('id' => $id, 'email'=> $email, 'token'=> $token, 'full_names' => $fullname, 'whatsapp' => $whatsapp, 'instagram' => $instagram, 'date' => $date);	
		}
		return $response;
	}

	public function getBlogCategories(){
		$response = array();
		$sql = "SELECT count(b.id) as total, c.category as category FROM $this->BLOG b INNER JOIN $this->BLOGCATEGORY c ON b.blog_category_fk = c.id GROUP BY c.category";
		$result = $this->conn->query($sql);
		$rowcount = mysqli_num_rows($result);
		
		while($row = $result->fetch_array()){
			$category = $row['category'];
			$total = $row['total'];
			$response[] = array('category'=> $category, 'total' => $total);	
		}
		return $response;
	}

	public function getBlogCategory(){
		$response = array();
		$sql = "SELECT * FROM $this->BLOGCATEGORY";
		$result = $this->conn->query($sql);
		$rowcount = mysqli_num_rows($result);
		
		while($row = $result->fetch_array()){
			$id = $row['id'];
			$category = $row['category'];
			$date = $row['date'];
		

			$publishdate = date_create($row['date']);
			$date = date_format($publishdate,"d M, Y");

			$response[] = array('id' => $id, 'category'=> $category, 'date' => $date);	
		}
		return $response;
	}
	
	public function isEmailExist($email) {
        $stmt = $this->conn->prepare("SELECT * from $this->USER WHERE email = ? ");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
	}
	
	public function updateUserPassword($email, $password){
		if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		require_once 'PassHash.php';
		$hash = PassHash::hash($password);

		$result = false; 
		$sql = "UPDATE $this->USER SET password_hash = ?  WHERE email = ?";
		if($stmt = $this->conn->prepare($sql)){
			$stmt->bind_param("ss", $hash, $email);
		if($stmt->execute()){
				$result = true;
			}
			else{
				var_dump($this->conn->error);
				$result = false;
			}
			$stmt->close();  
		}else{
			//error !! don't go further
			var_dump($this->conn->error);
			$result = false;
		}
		return $result;
	}

	/**********************************************************************/
	/*
	Generate 4-digit tracking code
	*/
	public function randomNumber(){
		$string = '0123456789';
		$string_shuffled = str_shuffle($string);
		$token = substr($string_shuffled, 1, 7);
		return $token;
	}

	
	public function manageOTP($email, $code){
        if(!empty($email)){
            //echo 'hello here niggaz';
			$minutes_to_add = 5;
			$startdate = date("Y-m-d H:i:s");
			$time = new DateTime($startdate);
			$time->add(new DateInterval('PT' . $minutes_to_add . 'M'));
			$enddate = $time->format('Y-m-d H:i:s');
			
            //Check whether user data already exists in database
            $prevQuery = "SELECT * FROM $this->OTP WHERE email = '$email'";
            $prevResult = $this->conn->query($prevQuery);
            if($prevResult->num_rows > 0){
				//$prevResult->close();
                //Update user data if already exists
                $query = "UPDATE $this->OTP SET code = '$code', startdate = '$startdate', enddate = '$enddate' WHERE email = '$email'";
                
                //echo 'update: '.$query;
				$update = $this->conn->query($query);
				//$update->close();
				$this->sendOTPmail($email, $code);
				
            }else{
                //Insert otp data
                $query = "INSERT INTO $this->OTP SET code = '$code', startdate = '$startdate', enddate = '$enddate', email = '$email'";
                
                //echo 'insert: '.$query;
				$insert = $this->conn->query($query);
				$this->sendOTPmail($email, $code);
				//$insert->close();
            }
        }
	}
	
	public function sendOTPmail($email, $code){

		$emailtitle = "Reset Password";
		$emailbody = "Visit this <a href='http://mixandshakesbybeeba.com/resetpassword?token=$code&email=$email'>link</a> to reset your password";
		$emailuser = $email;
		$emailsender = "Mix and Shakes By Beeba";
		$emailmessage = $this->getEmailTemplate($emailbody);
		$this->sendEmail($emailtitle, $emailmessage, $emailuser, $this->supportemail);
	}

	public function sendMail($receipent, $sender, $message, $subject, $headers){
	    require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

	    $mail = new PHPMailer(true);
	    try {
    //Server settings
    $mail->SMTPDebug = 0;                             // Enable verbose debug output
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'mail.mixandshakesbybeeba.com;mail.mixandshakesbybeeba.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = $this->supportemail;                 // SMTP username
    $mail->Password = $this->supportemailPassword;                           // SMTP password
    $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('beeba@mixandshakesbybeeba.com', 'Beeba');
    $mail->addAddress($receipent);     // Add a recipient
    $mail->addReplyTo('no-reply@mixandshakesbybeeba.com', 'No Reply');

    //Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = $subject;
    $mail->Body    = $message;
    $mail->AltBody = $message;

    $mail->send();
    //echo 'Message has been sent';
} catch (Exception $e) {
    //echo 'Message could not be sent.';
    //print_r('Mailer Error: ' . $mail->ErrorInfo);
}
		//return mail($receipent, $subject, $message, $headers);
	}
	
	public function sendEmail($title, $message, $receipentemail, $senderemail){
		$authoremail = $this->supportemail;
		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$headers .= 'From: MixAndShakesByBeeba <'.$senderemail. "> \r\n";
		$headers .= "Reply-To: no-reply@mixandshakesbybeeba.com\r\n";
		$this->sendMail($receipentemail, $senderemail, $message, $title, $headers);
	}

	public function isOTPValid($email, $code) {
	    if ($this->conn->connect_error) {
			trigger_error('Database connection failed: '  . $this->conn->connect_error, E_USER_ERROR);
		}
		$enddate = "";
		$sql = "select * from $this->OTP where email = '$email'  AND code = '$code'";
		$result = $this->conn->query($sql);
		while($row = $result->fetch_array()){
			$enddate = $row['enddate'];
			unset($row);
			break;
		}
		$result->close();
		unset($sql);
		
		$enddatex = strtotime($enddate);
		if (time() - $enddatex > 5 * 60) {
			//5 mins has passed
			return false;
		}
        
        return true;
	}
	
	public function getMailTemplate($message){
		$html = '<!DOCTYPE html>'.
					  '<html lang="en">'.
					  '<head>'.
					  ''.
					  '<meta name="viewport" content="width=device-width, initial-scale=1"/>'.
					  
					'</head>'.
		
					'<body style="background-color:#fafafa; font-style: inherit; font-family: verdana;">'.
					'<div style="box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2); transition: 0.3s; width: 90%; margin-left: auto; margin-right: auto;background-color:#ffffff;">'.
					  
		
					'<div style="margin-left:5px; margin-right:5px; margin-bottom:30px;">'.
						'<div class="row">'.
							//'<p style="margin-right:0; text-align: right;align-content: right;">'.$transactionid.'</p>'.
							
							'<div class="col s12">'.
								'<div class="col s12">'.
									'<div>'.
										'<div class="card-content">'.
											'<p>'.
												$message
											.'</p><br>'.
											'<span>Warm Regards</span><br><br> Beeba'.
											
										'</div>'.
									'</div>'.
								'</div>'.
							  
							'</div>'.
		
						'</div>'.
					'</div><br>'.
					'</div>'.
					'</body>'.
					'</html>';
				return $html;
	}

	public function getEmailTemplate($message){
		return '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
		<html xmlns="http://www.w3.org/1999/xhtml">
		
		<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
			
			<meta name="viewport" content="width=device-width" />
		
			<!-- For development, pass document through inliner -->
		
			<style type="text/css">
				* {
					margin: 0;
					padding: 0;
					font-size: 100%;
					font-family: "Avenir Next", "Helvetica Neue", "Helvetica", Helvetica, Arial, sans-serif;
					line-height: 1.65;
				}
				
				img {
					max-width: 100%;
					margin: 0 auto;
					display: block;
				}
				
				body,
				.body-wrap {
					width: 100% !important;
					height: 100%;
					background: #f8f8f8;
				}
				
				a {
					color: #71bc37;
					text-decoration: none;
				}
				
				a:hover {
					text-decoration: underline;
				}
				
				.text-center {
					text-align: center;
				}
				
				.text-right {
					text-align: right;
				}
				
				.text-left {
					text-align: left;
				}
				
				.button {
					display: inline-block;
					color: white;
					background: #199EB8;
					border: solid #199EB8;
					border-width: 10px 20px 8px;
					font-weight: bold;
					border-radius: 4px;
				}
				
				.button:hover {
					text-decoration: none;
				}
				
				h1,
				h2,
				h3,
				h4,
				h5,
				h6 {
					margin-bottom: 20px;
					line-height: 1.25;
				}
				
				h1 {
					font-size: 32px;
				}
				
				h2 {
					font-size: 28px;
				}
				
				h3 {
					font-size: 24px;
				}
				
				h4 {
					font-size: 20px;
				}
				
				h5 {
					font-size: 16px;
				}
				
				p,
				ul,
				ol {
					font-size: 16px;
					font-weight: normal;
					margin-bottom: 20px;
				}
				
				.container {
					display: block !important;
					clear: both !important;
					margin: 0 auto !important;
					max-width: 580px !important;
				}
				
				.container table {
					width: 100% !important;
					border-collapse: collapse;
				}
				
				.container .masthead {
					padding: 0px 0;
					background: white;
					color: white;
				}
				
				.container .masthead h1 {
					margin: 0 auto !important;
					max-width: 90%;
					text-transform: uppercase;
				}
				
				.container .content {
					background: white;
					padding: 30px 35px;
				}
				
				.container .content.footer {
					background: none;
				}
				
				.container .content.footer p {
					margin-bottom: 0;
					color: #888;
					text-align: center;
					font-size: 14px;
				}
				
				.container .content.footer a {
					color: #888;
					text-decoration: none;
					font-weight: bold;
				}
				
				.container .content.footer a:hover {
					text-decoration: underline;
				}
				
				.url {
					overflow-wrap: break-word;
					word-wrap: break-word;
					-ms-word-break: break-all;
					/* This is the dangerous one in WebKit, as it breaks things wherever */
					word-break: break-all;
					/* Instead use this non-standard one: */
					word-break: break-word;
					/* Adds a hyphen where the word breaks, if supported (No Blink) */
					-ms-hyphens: auto;
					-moz-hyphens: auto;
					-webkit-hyphens: auto;
					hyphens: auto;
				}
			</style>
		</head>
		
		<body>
			
			<table class="body-wrap">
				<tr>
					<td class="container">
		
						<!-- Message start -->
						<table>
							<tr><td>
			</td></tr>
							
							<tr>
								<td class="content">
		
									<h2>Hi,</h2>
		
									<p>'.$message.'</p>
	
									<p><em>– Beeba</em></p>
		
								</td>
							</tr>
							
						</table>
		
					</td>
				</tr>
				<tr>
					<td class="container">
						<!-- Message start -->
						<table>
							<tr>
								<td class="content footer" align="center">
									<p><a href="#">Mix and Shakes By Beeba</a>,  Abuja</p>
									<p><a href="mailto:"> Beebaluv28@gmail.com</a> |
										<phone>
											 +234 703 0312 000</phone></p>
								</td>
							</tr>
						</table>
		
					</td>
				</tr>
			</table>
		</body>
		
		</html>';
	}

}
?>