<?php
/**
 * Database configuration
 *
*/

define('DB_USERNAME', 'machineries');
define('DB_PASSWORD', 'Password@1');
define('DB_HOST', 'localhost');
define('DB_NAME', 'machineries');

// define('DB_USERNAME', 'root');
// define('DB_PASSWORD', 'root');
// define('DB_HOST', 'localhost:8889');
// define('DB_NAME', 'machineries');

?>