<!DOCTYPE html>
<html lang="zxx">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <title>topmachineries. Construction</title>
	<link rel="canonical" href="https://duruthemes.com/demo/html/norc/index2.html" />
    <link rel="shortcut icon" href="../../../demo/html/norc/img/favicon.png" />
    <link rel="stylesheet" href="../../../demo/html/norc/css/plugins.css" />
    <link rel="stylesheet" href="//fonts.googleapis.com/css2?family=Didact+Gothic&family=Syne:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="../../../demo/html/norc/css/style.css" />
    <style>
         [data-overlay-dark]:before, [data-overlay-light]:before {
    content: '';
    position: absolute;
    width: 100%;
    height: 70%;
    top: 0;
    left: 0;
    z-index: 1;
}
.btn.book-now {
            background-color: #000080;
        display:inline-block;
         border-radius: 0;
        color: #ffffff;
        display:inline-block;
        font-size: 1rem;
        height: 50px;
        line-height: 37px;
        position: fixed;
        right: 0;
        text-align: center;
        text-decoration: none;
        text-transform: uppercase;
        -moz-transform:rotate(-90deg);
        -ms-transform:rotate(-90deg);
        -o-transform:rotate(-90deg);
        -webkit-transform:rotate(-90deg);
        transform-origin: bottom right;
        /* width: 100px; */
        z-index: 2;
        writing-mode: vertical-rl;
        /* Hover styles, 
        media queries */
        
       } 
       .btn.book-now:hover {
        background-color: black;
        color: white;
        }

    </style>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader-bg"></div>
    <div id="preloader">
        <div id="preloader-status">
            <div class="preloader-position loader"> <span></span> </div>
        </div>
    </div>
    <!-- Progress scroll totop -->
    <div class="progress-wrap">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
        </svg>
    </div>
    <!-- Top Navbar -->
    <div class="main-header">
        <div class="header-top">
            <div class="container">
                <div class="top-outer clearfix">
                    <!--Top Left-->
                    <div class="top-left">
                        <ul class="links clearfix">
                            <li><a href="tel:+12033334444"><span class="fa fa-phone"></span>+1 203-333-4444</a></li>
                            <li><a href="mailto:info@construction.com"><span class="fa fa-envelope"></span>info@construction.com</a></li>
                            <li><a href="https://goo.gl/maps/zgdqkg4hFFR8pfDS8" target="_blank"><span class="fa fa-map-marker"></span>24 King St, SC 29401 USA</a></li>
                        </ul>
                    </div>
                    <!--Top Right-->
                    <div class="top-right clearfix">
                        <ul class="social-icon-one">
                            <li>
                                <a href="#" class="fa fa-whatsapp"></a>
                            </li>
                            <li>
                                <a href="#" class="fa fa-twitter"></a>
                            </li>
                            <li>
                                <a href="#" class="fa fa-instagram"></a>
                            </li>
                            <li>
                                <a href="#" class="fa fa-youtube-play"></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-md">
        <div class="container">
            <!-- Logo -->
            <img style="width: 20%; height: 20%;" src="../../../demo/html/norc/images/logo.png" alt="logo">
            <!-- <a class="logo" href="../../../index.php"> <img src="../../../demo/html/norc/images/logo.png" alt=""> </a> -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar" aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"><i class="fa fa-bars"></i></span> </button>
            <!-- Navbar links -->
            <div class="collapse navbar-collapse" id="navbar">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="../../../index.php">HOME</a></li>
                    <!-- <li class="nav-item dropdown"> <span class="nav-link active"> Home <i class="fa fa-angle-down"></i></span> -->
                        <!-- <ul class="dropdown-menu last">
                            <li class="dropdown-item active"><a href="index.html">Home Layout 01</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/index2.html">Home Layout 02</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/index3.html">Home Layout 03</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/index4.html">Home Layout 04</a></li>
                        </ul> -->
                    </li>
                    <li class="nav-item"><a class="nav-link" href="about.php">ABOUT US</a></li>
                    <li class="nav-item dropdown"> <span class="nav-link"> PRODUCTS <i class="fa fa-angle-down"></i></span>
                        <ul class="dropdown-menu last">
                            <li class="dropdown-item"><a href="new_machines.php">NEW MACHINES</a></li>
                            <li class="dropdown-item"><a href="office_machines.php">OFFICE MACHINES</a></li>
                            <li class="dropdown-item"><a href="home_machines.php">HOME MACHINES</a></li>
                            <li class="dropdown-item"><a href="agricultural_machines.php">AGRICULTURAL MACHINES</a></li>
                            <li class="dropdown-item"><a href="technological_machines.php">TECHNOLOGICAL MACHINES</a></li>
                            <li class="dropdown-item"><a href="computer_machines.php">COMPUTER MACHINES</a></li>
                            <li class="dropdown-item"><a href="others_machines.php">OTHERS</a></li>
                        </ul>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="services2.php">INDUSTRIES</a></li>
                    <!-- <li class="nav-item dropdown"> <span class="nav-link"> Projects <i class="fa fa-angle-down"></i></span>
                        <ul class="dropdown-menu last">
                            <li class="dropdown-item"><a href="demo/html/norc/projects.html">Projects 01</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/projects2.html">Projects 02</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/project-page.html">Projects Page</a></li>
                        </ul>
                    </li> -->
                    <!-- <li class="nav-item dropdown"> <span class="nav-link"> SUPPORT <i class="fa fa-angle-down"></i></span>
                        <ul class="dropdown-menu last">
                            <li class="dropdown-item"><a href="image-gallery.html">CATALOGUES</a></li>
                            <li class="dropdown-item"><a href="video-gallery.html">MANUALS</a></li>
                            <li class="dropdown-item"><a href="pricing.html">CERTIFICATES</a></li>
                            <li class="dropdown-item"><a href="team.html">VIDEOS</a></li>
                            <li class="dropdown-item"><a href="careers.html">SOFTEARE</a></li> -->
                            <!-- <li class="dropdown-item"><a href="demo/html/norc/testimonials.html">Testimonials</a></li>
                            <li class="dropdown-item"><span>Other <i class="fa fa-angle-right"></i></span>
                                <ul class="sub-menu">
                                    <li class="dropdown-item"><a href="demo/html/norc/faqs.html">Faqs</a></li>
                                    <li class="dropdown-item"><a href="demo/html/norc/404.html">404 Page</a></li>
                                </ul>
                            </li> -->
                        <!-- </ul>
                    </li> -->
                    <li class="nav-item"><a class="nav-link" href="services3.php">NEWS</a></li>
                    <!-- <li class="nav-item dropdown"> <span class="nav-link"> NEWS <i class="fa fa-angle-down"></i></span>
                        <ul class="dropdown-menu last">
                            <li class="dropdown-item"><a href="demo/html/norc/blog.html">Blog 01</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/blog2.html">Blog 02</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/post.html">Post Page</a></li>
                        </ul>
                    </li> -->
                    <li class="nav-item"><a class="nav-link" href="index2.php">CONTACT</a></li>
                </ul>
            </div>
        </div>
    </nav>

    
    <a class="btn book-now desktop open-datepicker-popup" href="index4.html" title="Book Now" style="font-weight: 100px; font-size: larger; background-color: #000080;">G<br>E<br>T<br> Q<br>U<br>O<br>T<br>E</a>
    <div class="scroller"></div>

    <!-- Slider -->
    <header class="header slider-fade">
        <div class="row">
            <div class="col">
                <img src="images/FOD-400x300.png" />

            </div>
            <div class="col">
                <div class="section-title">Factory <span>Location</span></div>
                <ul class="listext list-unstyled mb-30">
                    <li>
                        <div class="listext-icon"> <i class="fa-thin fa-location-dot"></i> </div>
                        <div class="listext-text">
                            <p>Factory Address No 2649, tianedang Road, Wuzhong District 215103 Suchou City, Jiangsu Province, China Office Address Room 812, Building 3, Tiandu, No 211 Changjiang Road, Suzhou City, Jiangsu Province China</p>
                        </div>
                    </li>
                    <li>
                        <div class="listext-icon"> <i class="fa-thin fa-address-book"></i> </div>
                        <div class="listext-text">
                            <p>+86-512-67898765</p>
                        </div>
                    </li>
                    <li>
                        <div class="listext-icon"> <i class="fa-thin fa-envelope"></i> </div>
                        <div class="listext-text">
                            <p>info@topmachineries.com</p>
                        </div>
                    </li>
                    <li>
                        <div class="listext-icon"> <a href="#" class="fa fa-whatsapp"></a> </div>
                        <div class="listext-text">
                            <p>Eileen: +234706558990</p>
                        </div>
                    </li>
                    <li>
                        <div class="listext-icon"> <a href="#" class="fa fa-whatsapp"></a> </div>
                        <div class="listext-text">
                            </a><p>Wanda: +8634567980</p>
                        </div>
                    </li>
                    <li>
                        <div class="listext-icon"> <a href="#" class="fa fa-whatsapp"></a> </div>
                        <div class="listext-text">
                            </a><p>Mary: +86098754327</p>
                        </div>
                    </li>
                </ul>


            </div>

        </div>
       
    </header>
    <!-- About -->
    <section class="about section-padding">
        <div class="container">
            <div class="row">
               <div class="col">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d126845.96885288632!2d3.2934878881787553!3d6.52970116907018!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x103b9228fa2a3999%3A0xd7a8324bddbba1f0!2sIkeja%2C%20Lagos!5e0!3m2!1sen!2sng!4v1679004979439!5m2!1sen!2sng" width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
               </div>
               <div class="col">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d26953389.038622227!2d86.02212029616021!3d34.446851726784644!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31508e64e5c642c1%3A0x951daa7c349f366f!2sChina!5e0!3m2!1sen!2sng!4v1679005474537!5m2!1sen!2sng" width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
               </div>
                
            </div>
        </div>
    </section>
    <!-- Services -->
    <section class="services2 center section-padding bg-gray">
        <div class="container">
            <div style="text-align: center;" class="row">
                <div class="section-title">Contact <span>Form</span></div>
                <form method="post" action="../../../form_submit.php" class="contact__form">
                    <!-- Form message -->
                    <div class="row">
                        <div class="col-12">
                            <div class="alert alert-success contact__msg" style="display: none" role="alert"> Your message was sent successfully. </div>
                        </div>
                    </div>
                    <!-- Form elements -->
                    <div class="row">
                        <div class="col-md-12 form-group">
                            <input name="name" type="text" placeholder="Your Name *" required="">
                        </div>
                        <div class="col-md-12 form-group">
                            <input name="email" type="email" placeholder="Your Email *" required="">
                        </div>
                        <div class="col-md-12 form-group">
                            <input name="phone" type="text" placeholder="Your Number *" required="">
                        </div>
                        <div class="form-group">
                            <!-- <label for="exampleFormControlTextarea1">Example textarea</label> -->
                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                          </div>
                        <div class="col-md-12">
                            <button type="submit" class="button-secondary mt-15"><span>Submit</span></button>
                        </div>
                    </div>
                    <input name="ops" type="hidden" value="contact">
                </form>
                
            </div>
        </div>
    </section>
      <!-- Footer -->
      <footer class="footer clearfix">
        <div class="container">
            <!-- First footer -->
            <div class="first-footer">
                <div class="row">
                    <div class="col-md-12">
                        <div class="links dark footer-contact-links">
                            <div class="footer-contact-links-wrapper">
                                <div class="footer-contact-link-wrapper">
                                    <div class="image-wrapper footer-contact-link-icon">
                                        <div class="icon-footer"> <i class="norc-phone"></i> </div>
                                    </div>
                                    <div class="footer-contact-link-content">
                                        <h6>Call us</h6>
                                        <p>+1 203-333-4444</p>
                                    </div>
                                </div>
                                <div class="footer-contact-links-divider"></div>
                                <div class="footer-contact-link-wrapper">
                                    <div class="image-wrapper footer-contact-link-icon">
                                        <div class="icon-footer"> <i class="norc-mail"></i> </div>
                                    </div>
                                    <div class="footer-contact-link-content">
                                        <h6>Write to us</h6>
                                        <p>info@construction.com</p>
                                    </div>
                                </div>
                                <div class="footer-contact-links-divider"></div>
                                <div class="footer-contact-link-wrapper">
                                    <div class="image-wrapper footer-contact-link-icon">
                                        <div class="icon-footer"> <i class="norc-property-location"></i> </div>
                                    </div>
                                    <div class="footer-contact-link-content">
                                        <h6>Address</h6>
                                        <p>24 King St, SC 29401 USA</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Second footer -->
            <div class="second-footer">
                <div class="row">
                    <!-- about & social icons -->
                    <div class="col-md-4 widget-area">
                        <div class="widget clearfix">
                            <h3 class="widget-title">About Norc.</h3>
                            <div class="widget-text">
                                <p>Quisque imperdiet sapien porttito the bibendum sellentesque the commodo erat acar accumsa lobortis, enim diam the nesuen.</p>
                                <div class="social-icons">
                                    <ul class="list-inline">
                                        <li><a href="#"><i class="fa fa-whatsapp"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                        <li><a href="#"><i class="fa fa-youtube-play"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- quick links -->
                    <div class="col-md-3 offset-md-1 widget-area">
                        <div class="widget clearfix usful-links">
                            <h3 class="widget-title">Quick Links</h3>
                            <ul>
                                <li><a href="../../../indexx.html">HOME</a></li>
                                <li><a href="about.html">ABOUT US</a></li>
                                <li><a href="services.php">PRODUCTS </a></li>
                                <li><a href="services2.php">INDUSTRIES</a></li>
                                <!-- <li><a href="demo/html/norc/blog.html">SUPPORT</a></li> -->
                                <li><a href="services3.php">NEWS</a></li>
                                <li><a href="index2.php">CONTACT</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- subscribe -->
                    <div class="col-md-4 widget-area">
                        <div class="widget clearfix">
                            <h3 class="widget-title">Subscribe</h3>
                            <p>Want to be notified about our news. Just sign up and we'll send you a notification by email.</p>
                            <div class="widget-newsletter">
                                <form method="POST" action="../../../footer.php">
                                    <p style="color: red; text-align: center;"> <?PHP if (isset($error)){echo $error;} ?></p>
                                    <input type="email" name="subcription" placeholder="Email Address" required>
                                    <button name="submit" type="submit">Send</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Bottom footer -->
            <div class="bottom-footer-text">
                <div class="row copyright">
                    <div class="col-md-12">
                        <p style="text-align: center;" class="mb-0">©2022 <a href="#">topmachineries</a>. All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- jQuery -->
    <script src="../../../demo/html/norc/js/jquery-3.6.0.min.js"></script>
    <script src="../../../demo/html/norc/js/jquery-migrate-3.0.0.min.js"></script>
    <script src="../../../demo/html/norc/js/modernizr-2.6.2.min.js"></script>
    <script src="../../../demo/html/norc/js/imagesloaded.pkgd.min.js"></script>
    <script src="../../../demo/html/norc/js/jquery.isotope.v3.0.2.js"></script>
    <script src="../../../demo/html/norc/js/popper.min.js"></script>
    <script src="../../../demo/html/norc/js/bootstrap.min.js"></script>
    <script src="../../../demo/html/norc/js/scrollIt.min.js"></script>
    <script src="../../../demo/html/norc/js/jquery.waypoints.min.js"></script>
    <script src="../../../demo/html/norc/js/owl.carousel.min.js"></script>
    <script src="../../../demo/html/norc/js/jquery.stellar.min.js"></script>
    <script src="../../../demo/html/norc/js/jquery.magnific-popup.js"></script>
    <script src="../../../demo/html/norc/js/jquery.counterup.min.js"></script>
    <script src="../../../demo/html/norc/js/YouTubePopUp.js"></script>
    <script src="../../../demo/html/norc/js/custom.js"></script>
</body>
</html>