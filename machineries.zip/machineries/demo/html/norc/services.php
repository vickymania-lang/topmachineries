
<?php
 include('../../../connection_db.php'); 


 
 ?>



<!DOCTYPE html>
<html lang="zxx">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <title>products</title>
	<link rel="canonical" href="https://duruthemes.com/demo/html/norc/services.html" />
    <link rel="shortcut icon" href="../../../demo/html/norc/img/favicon.png" />
    <link rel="stylesheet" href="../../../demo/html/norc/css/plugins.css" />
    <link rel="stylesheet" href="//fonts.googleapis.com/css2?family=Didact+Gothic&family=Syne:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="../../../demo/html/norc/css/style.css" /> 
    <style>
         [data-overlay-dark]:before, [data-overlay-light]:before {
    content: '';
    position: absolute;
    width: 100%;
    height: 70%;
    top: 0;
    left: 0;
    z-index: 1;
}
        .img1 {
            width: 50%;
            height: 50%;
        }
        .btn.book-now {
            background-color: #000080;
        display:inline-block;
         border-radius: 0;
        color: #ffffff;
        display:inline-block;
        font-size: 1rem;
        height: 50px;
        line-height: 37px;
        position: fixed;
        right: 0;
        text-align: center;
        text-decoration: none;
        text-transform: uppercase;
        -moz-transform:rotate(-90deg);
        -ms-transform:rotate(-90deg);
        -o-transform:rotate(-90deg);
        -webkit-transform:rotate(-90deg);
        transform-origin: bottom right;
        /* width: 100px; */
        z-index: 2;
        writing-mode: vertical-rl;
        /* Hover styles, 
        media queries */
        
       } 

       .btn.book-now:hover {
        background-color: black;
        color: white;
        }
    </style>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader-bg"></div>
    <div id="preloader">
        <div id="preloader-status">
            <div class="preloader-position loader"> <span></span> </div>
        </div>
    </div>
    <!-- Progress scroll totop -->
    <div class="progress-wrap cursor-pointer">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
        </svg>
    </div>
    <!-- Top Navbar -->
	<div class="main-header">
		<div class="header-top">
			<div class="container">
				<div class="top-outer clearfix">
					<!--Top Left-->
					<div class="top-left">
						<ul class="links clearfix">
							<li><a href="tel:+12033334444"><span class="fa fa-phone"></span>+1 203-333-4444</a></li>
							<li><a href="mailto:info@construction.com"><span class="fa fa-envelope"></span>info@construction.com</a></li>
							<li><a href="https://goo.gl/maps/zgdqkg4hFFR8pfDS8" target="_blank"><span class="fa fa-map-marker"></span>24 King St, SC 29401 USA</a></li>
						</ul>
					</div>
					<!--Top Right-->
					<div class="top-right clearfix">
						<ul class="social-icon-one">
							<li><a href="#" class="fa fa-whatsapp"></a></li>
							<li><a href="#" class="fa fa-twitter"></a></li>
							<li><a href="#" class="fa fa-instagram"></a></li>
							<li><a href="#" class="fa fa-youtube-play"></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-md">
        <div class="container">
            <!-- Logo -->
            <img style="width: 20%; height: 20%;" src="../../../demo/html/norc/images/logo.png" alt="logo">
            <!-- <a class="logo" href="../../../index.php"> <img src="../../../demo/html/norc/images/logo.png" alt=""> </a> -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar" aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"><i class="fa fa-bars"></i></span> </button>
            <!-- Navbar links -->
            <div class="collapse navbar-collapse" id="navbar">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="../../../index.php">HOME</a></li>
                    <!-- <li class="nav-item dropdown"> <span class="nav-link active"> Home <i class="fa fa-angle-down"></i></span> -->
                        <!-- <ul class="dropdown-menu last">
                            <li class="dropdown-item active"><a href="index.html">Home Layout 01</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/index2.html">Home Layout 02</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/index3.html">Home Layout 03</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/index4.html">Home Layout 04</a></li>
                        </ul> -->
                    </li>
                    <li class="nav-item"><a class="nav-link" href="about.html">ABOUT US</a></li>
                    <li class="nav-item dropdown"> <span class="nav-link"> PRODUCTS <i class="fa fa-angle-down"></i></span>
                        <ul class="dropdown-menu last">
                        <li class="dropdown-item"><a href="new_machines.php">NEW MACHINES</a></li>
                        <li class="dropdown-item"><a href="office_machines.php">OFFICE MACHINES</a></li>
                            <li class="dropdown-item"><a href="home_machines.php">HOME MACHINES</a></li>
                            <li class="dropdown-item"><a href="agricultural_machines.php">AGRICULTURAL MACHINES</a></li>
                            <li class="dropdown-item"><a href="technological_machines.php">TECHNOLOGICAL MACHINES</a></li>
                            <li class="dropdown-item"><a href="computer_machines.php">COMPUTER MACHINES</a></li>
                            <li class="dropdown-item"><a href="others_machines.php">OTHERS</a></li>
                        </ul>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="services2.php">INDUSTRIES</a></li>
                    <!-- <li class="nav-item dropdown"> <span class="nav-link"> Projects <i class="fa fa-angle-down"></i></span>
                        <ul class="dropdown-menu last">
                            <li class="dropdown-item"><a href="demo/html/norc/projects.html">Projects 01</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/projects2.html">Projects 02</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/project-page.html">Projects Page</a></li>
                        </ul>
                    </li> -->
                    <!-- <li class="nav-item dropdown"> <span class="nav-link"> SUPPORT <i class="fa fa-angle-down"></i></span>
                        <ul class="dropdown-menu last">
                            <li class="dropdown-item"><a href="demo/html/norc/image-gallery.html">CATALOGUES</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/video-gallery.html">MANUALS</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/pricing.html">CERTIFICATES</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/team.html">VIDEOS</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/careers.html">SOFTEARE</a></li> -->
                            <!-- <li class="dropdown-item"><a href="demo/html/norc/testimonials.html">Testimonials</a></li>
                            <li class="dropdown-item"><span>Other <i class="fa fa-angle-right"></i></span>
                                <ul class="sub-menu">
                                    <li class="dropdown-item"><a href="demo/html/norc/faqs.html">Faqs</a></li>
                                    <li class="dropdown-item"><a href="demo/html/norc/404.html">404 Page</a></li>
                                </ul>
                            </li> -->
                        <!-- </ul>
                    </li> -->
                    <li class="nav-item"><a class="nav-link" href="services3.php">NEWS</a></li>
                    <!-- <li class="nav-item dropdown"> <span class="nav-link"> NEWS <i class="fa fa-angle-down"></i></span>
                        <ul class="dropdown-menu last">
                            <li class="dropdown-item"><a href="demo/html/norc/blog.html">Blog 01</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/blog2.html">Blog 02</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/post.html">Post Page</a></li>
                        </ul>
                    </li> -->
                    <li class="nav-item"><a class="nav-link" href="index2.php">CONTACT</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <a class="btn book-now desktop open-datepicker-popup" href="index4.html" title="Book Now" style="font-weight: 100px; background-color: #000080;">G<br>E<br>T<br> Q<br>U<br>O<br>T<br>E</a>
    <div class="scroller"></div>


    <!-- Header Banner -->
    <section style="margin: 20PX;" class="banner-header banner-img-top section-padding valign bg-img bg-fixed" data-overlay-dark="4" data-background="img/slider/1.jpg">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <!-- <h6>What We Do</h6> -->
                    <h1>Our <span>products</span></h1>
                </div>
            </div>
        </div>
    </section>
    <!-- Services -->


    <div id="products" style="text-align: center;" class="row">

    <?php
        $products = mysqli_query($conn, "SELECT * FROM `our_product` ORDER BY `id` DESC LIMIT 16 ");
        while($row_pro  = mysqli_fetch_assoc($products)){
                    extract($row_pro) ;      
    ?>


        <div class="col-lg-3 col-md-6 col-sm-12">
            <div>
                <img class="img1" src="../../../images/<?php echo $ads_file; ?>" />
                <div>
                    <h6><?php echo $machine_name; ?></h6>
                    <p style="text-align: center;"><?php echo $short_details; ?></p>
                    <a href="../../../images/files/<?php echo $ads_file2 ?>" download="files"><i class="norc-new-construction"></i><b>Download</b></a><br>
                    <button class="btn btn-primary"><a  href="services-page.php?user_id=<?php echo $row_pro['id']; ?>">More details</a></button>
                </div>
            </div>
        </div>


        <?php } ?>


<!-- other services -->
<section class="services center section-padding bg-gray">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-subtitle">Available</div>
                <div class="section-title">Other <span>Products</span></div>
            </div>
        </div>
        <div class="row">

            <div class="col-md-12 owl-carousel owl-theme">

            <?php
                $products = mysqli_query($conn, "SELECT * FROM `our_product` LIMIT 5 ");
                while($row_pro  = mysqli_fetch_assoc($products)){
                            extract($row_pro) ;      
            ?>

                <div class="item mb-30">
                    <div class="service-img">
                        <div class="img"> <img src="../../../images/<?php echo $ads_file; ?>" alt=""> </div>
                    </div>
                    <div class="cont">
                        <div class="service-icon"> <i class="norc-construction-sign"></i> </div>
                        <h5><a href="services-page.php?user_id=<?php echo $row_pro['id']; ?>">General Contracting</a></h5>
                        <p>Quisque imperdie miss sapien porttiton the bibendum. Pellentesque accumsa amet tincidunt risus nesuen.</p> <a href="services-page.php?user_id=<?php echo $row_pro['id']; ?>" class="link-btn" tabindex="0">View service</a>
                    </div>
                </div>

            <?php } ?>

               
            </div>
        </div>
    </div>
</section>

    <!-- Footer -->
    <footer class="footer clearfix">
        <div class="container">
            <!-- First footer -->
            <div class="first-footer">
                <div class="row">
                    <div class="col-md-12">
                        <div class="links dark footer-contact-links">
                            <div class="footer-contact-links-wrapper">
                                <div class="footer-contact-link-wrapper">
                                    <div class="image-wrapper footer-contact-link-icon">
                                        <div class="icon-footer"> <i class="norc-phone"></i> </div>
                                    </div>
                                    <div class="footer-contact-link-content">
                                        <h6>Call us</h6>
                                        <p>+1 203-333-4444</p>
                                    </div>
                                </div>
                                <div class="footer-contact-links-divider"></div>
                                <div class="footer-contact-link-wrapper">
                                    <div class="image-wrapper footer-contact-link-icon">
                                        <div class="icon-footer"> <i class="norc-mail"></i> </div>
                                    </div>
                                    <div class="footer-contact-link-content">
                                        <h6>Write to us</h6>
                                        <p>info@construction.com</p>
                                    </div>
                                </div>
                                <div class="footer-contact-links-divider"></div>
                                <div class="footer-contact-link-wrapper">
                                    <div class="image-wrapper footer-contact-link-icon">
                                        <div class="icon-footer"> <i class="norc-property-location"></i> </div>
                                    </div>
                                    <div class="footer-contact-link-content">
                                        <h6>Address</h6>
                                        <p>24 King St, SC 29401 USA</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Second footer -->
            <div class="second-footer">
                <div class="row">
                    <!-- about & social icons -->
                    <div class="col-md-4 widget-area">
                        <div class="widget clearfix">
                            <h3 class="widget-title">About Norc.</h3>
                            <div class="widget-text">
                                <p>Quisque imperdiet sapien porttito the bibendum sellentesque the commodo erat acar accumsa lobortis, enim diam the nesuen.</p>
                                <div class="social-icons">
                                    <ul class="list-inline">
                                        <li><a href="#"><i class="fa fa-whatsapp"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                        <li><a href="#"><i class="fa fa-youtube-play"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- quick links -->
                    <div class="col-md-3 offset-md-1 widget-area">
                        <div class="widget clearfix usful-links">
                            <h3 class="widget-title">Quick Links</h3>
                            <ul>
                                <li><a href="../../../index.php">HOME</a></li>
                                <li><a href="about.php">ABOUT US</a></li>
                                <li><a href="services.php">PRODUCTS </a></li>
                                <li><a href="services2.php">INDUSTRIES</a></li>
                                <!-- <li><a href="demo/html/norc/blog.html">SUPPORT</a></li> -->
                                <li><a href="services3.php">NEWS</a></li>
                                <li><a href="index2.php">CONTACT</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- subscribe -->
                    <div class="col-md-4 widget-area">
                        <div class="widget clearfix">
                            <h3 class="widget-title">Subscribe</h3>
                            <p>Want to be notified about our news. Just sign up and we'll send you a notification by email.</p>
                            <div class="widget-newsletter">
                                <form method="POST" action="../../../footer.php">
                                    <p style="color: red; text-align: center;"> <?PHP if (isset($error)){echo $error;} ?></p>
                                    <input type="email" name="subcription" placeholder="Email Address" required>
                                    <button name="submit" type="submit">Send</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Bottom footer -->
            <div class="bottom-footer-text">
                <div class="row copyright">
                    <div class="col-md-12">
                        <p style="text-align: center;" class="mb-0">©2022 <a href="#">topmachineries</a>. All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- jQuery -->
    <script src="../../../demo/html/norc/js/jquery-3.6.0.min.js"></script>
    <script src="../../../demo/html/norc/js/jquery-migrate-3.0.0.min.js"></script>
    <script src="../../../demo/html/norc/js/modernizr-2.6.2.min.js"></script>
    <script src="../../../demo/html/norc/js/imagesloaded.pkgd.min.js"></script>
    <script src="../../../demo/html/norc/js/jquery.isotope.v3.0.2.js"></script>
    <script src="../../../demo/html/norc/js/popper.min.js"></script>
    <script src="../../../demo/html/norc/js/bootstrap.min.js"></script>
    <script src="../../../demo/html/norc/js/scrollIt.min.js"></script>
    <script src="../../../demo/html/norc/js/jquery.waypoints.min.js"></script>
    <script src="../../../demo/html/norc/js/owl.carousel.min.js"></script>
    <script src="../../../demo/html/norc/js/jquery.stellar.min.js"></script>
    <script src="../../../demo/html/norc/js/jquery.magnific-popup.js"></script>
    <script src="../../../demo/html/norc/js/jquery.counterup.min.js"></script>
    <script src="../../../demo/html/norc/js/YouTubePopUp.js"></script>
    <script src="../../../demo/html/norc/js/custom.js"></script>
</body>
</html>