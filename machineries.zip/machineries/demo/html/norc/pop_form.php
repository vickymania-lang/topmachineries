<?php

if(isset($_POST['submit'])) {
    $to = "ogungbuyivictor@gmail.com";
    $from = $_POST['email'];
    $name = $_POST['name'];
    $your_message = $_POST['your_message'];



$subject = "form submission";
$subject2 = "copy of your submission";
$message = $name . " " . "wrote the following:" . "\n\n" . $_POST['your_message'];
$message2 = "Here is a copy of your message" . $name . "\n\n" . $_POST['your_message'];

$headers = "From:" . $from;
$headers2 = "From:" . $to;
mail($to, $subject, $message, $headers);
mail($from, $subject2, $message2, $headers2);
echo "Mail Sent. Thank you " . $name . ", we will contact you shortly. ";


}


?>

