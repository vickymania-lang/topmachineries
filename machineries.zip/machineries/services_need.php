<?php
include 'connection_db.php';


$stmt = $conn -> prepare("SELECT * FROM  our_products LIMIT 6");

$stmt->execute();

$products = $stmt -> get_result();



?>