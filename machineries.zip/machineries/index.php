<?php

include('connection_db.php');



?>






<!DOCTYPE html>
<html lang="zxx">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <title>Top Machineries</title>
	<link rel="canonical" href="https://duruthemes.com" />
    <link rel="shortcut icon" href="demo/html/norc/img/favicon.png" />
    <link rel="stylesheet" href="demo/html/norc/css/plugins.css" />
    <link rel="stylesheet" href="//fonts.googleapis.com/css2?family=Didact+Gothic&family=Syne:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="demo/html/norc/css/style.css" />
    <style>
       .btn.book-now {
       
        
        background-color: #000080;
        display:inline-block;
         border-radius: 0;
        color: #ffffff;
        display:inline-block;
        font-size: 1rem;
        height: 50px;
        line-height: 37px;
        position: fixed;
        right: 0;
        text-align: center;
        text-decoration: none;
        text-transform: uppercase;
        -moz-transform:rotate(-90deg);
        -ms-transform:rotate(-90deg);
        -o-transform:rotate(-90deg);
        -webkit-transform:rotate(-90deg);
        transform-origin: bottom right;
        /* width: 100px; */
        z-index: 2;
        writing-mode: vertical-rl;
        /* Hover styles, 
        media queries */
        
       } 
       .btn.book-now:hover {
        background-color: black;
        color: white;
        }

        #get-quote-btn {
    text-align: center;
    position: fixed;
    z-index: 9999;
    top: 70%;
    right: 0;
    transform: translateY(-50%);
    -webkit-transform: translateY(-50%);
    box-shadow: 0 0 20px rgba(0,0,0,.4);
    -webkit-box-shadow: 0 0 20px rgba(0,0,0,.4);
    background: #000080;
    color: #fff;
    text-decoration: none;
    font-size: 15px;
    padding: 10px 15px;
}


    </style>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader-bg"></div>
    <div id="preloader">
        <div id="preloader-status">
            <div class="preloader-position loader"> <span></span> </div>
        </div>
    </div>
    <!-- Progress scroll totop -->
    <div class="progress-wrap">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
        </svg>
    </div>
    <!-- Top Navbar -->
    <div class="main-header">
        <div class="header-top">
            <div class="container">
                <div class="top-outer clearfix">
                    <!--Top Left-->
                    <div class="top-left">
                        <ul class="links clearfix">
                            <li><a href="tel:+12033334444"><span class="fa fa-phone"></span>+234 803-333-4456</a></li>
                            <li><a href="mailto:info@construction.com"><span class="fa fa-envelope"></span>info@topmachineries.com</a></li>
                            <li><a href="https://goo.gl/maps/zgdqkg4hFFR8pfDS8" target="_blank"><span class="fa fa-map-marker"></span>24 King St, SC 29401 China</a></li>
                        </ul>
                    </div>
                    <!--Top Right-->
                    <div class="top-right clearfix">
                        <ul class="social-icon-one">
                            <li>
                                <a href="#" class="fa fa-whatsapp"></a>
                            </li>
                            <li>
                                <a href="#" class="fa fa-twitter"></a>
                            </li>
                            <li>
                                <a href="#" class="fa fa-instagram"></a>
                            </li>
                            <li>
                                <a href="#" class="fa fa-youtube-play"></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-md">
        <div class="container">
            <!-- Logo -->
            <img style="width: 20%; height: 20%;" src="demo/html/norc/images/logo.png" alt="logo">
            <!-- <a class="logo" href="index.php"> <img src="demo/html/norc/images/logo.png" alt=""> </a> -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar" aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"><i class="fa fa-bars"></i></span> </button>
            <!-- Navbar links -->
            <div class="collapse navbar-collapse" id="navbar">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="index.php">HOME</a></li>
                    <!-- <li class="nav-item dropdown"> <span class="nav-link active"> Home <i class="fa fa-angle-down"></i></span> -->
                        <!-- <ul class="dropdown-menu last">
                            <li class="dropdown-item active"><a href="index.html">Home Layout 01</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/index2.html">Home Layout 02</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/index3.html">Home Layout 03</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/index4.html">Home Layout 04</a></li>
                        </ul> -->
                    </li>
                    <li class="nav-item"><a class="nav-link" href="demo/html/norc/about.php">ABOUT US</a></li>
                    <li class="nav-item dropdown"> <span class="nav-link"> PRODUCTS <i class="fa fa-angle-down"></i></span>
                        <ul class="dropdown-menu last">
                            <li class="dropdown-item"><a href="demo/html/norc/new_machines.php">NEW MACHINES</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/office_machines.php">OFFICE MACHINES</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/home_machines.php">HOME MACHINES</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/agricultural_machines.php">AGRICULTURAL MACHINES</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/technological_machines.php">TECHNOLOGICAL MACHINES</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/computer_machines.php">COMPUTER MACHINES</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/others_machines.php">OTHERS</a></li>
                        </ul>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="demo/html/norc/services2.php">INDUSTRIES</a></li>
                    <!-- <li class="nav-item dropdown"> <span class="nav-link"> Projects <i class="fa fa-angle-down"></i></span>
                        <ul class="dropdown-menu last">
                            <li class="dropdown-item"><a href="demo/html/norc/projects.html">Projects 01</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/projects2.html">Projects 02</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/project-page.html">Projects Page</a></li>
                        </ul>
                    </li> -->
                    <!-- <li class="nav-item dropdown"> <span class="nav-link"> SUPPORT <i class="fa fa-angle-down"></i></span>
                        <ul class="dropdown-menu last">
                            <li class="dropdown-item"><a href="demo/html/norc/image-gallery.html">CATALOGUES</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/video-gallery.html">MANUALS</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/pricing.html">CERTIFICATES</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/team.html">VIDEOS</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/careers.html">SOFTEARE</a></li> -->
                            <!-- <li class="dropdown-item"><a href="demo/html/norc/testimonials.html">Testimonials</a></li>
                            <li class="dropdown-item"><span>Other <i class="fa fa-angle-right"></i></span>
                                <ul class="sub-menu">
                                    <li class="dropdown-item"><a href="demo/html/norc/faqs.html">Faqs</a></li>
                                    <li class="dropdown-item"><a href="demo/html/norc/404.html">404 Page</a></li>
                                </ul>
                            </li> -->
                        <!-- </ul>
                    </li> -->
                    <li class="nav-item"><a class="nav-link" href="demo/html/norc/services3.php">NEWS</a></li>
                    <!-- <li class="nav-item dropdown"> <span class="nav-link"> NEWS <i class="fa fa-angle-down"></i></span>
                        <ul class="dropdown-menu last">
                            <li class="dropdown-item"><a href="demo/html/norc/blog.html">Blog 01</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/blog2.html">Blog 02</a></li>
                            <li class="dropdown-item"><a href="demo/html/norc/post.html">Post Page</a></li>
                        </ul>
                    </li> -->
                    <li class="nav-item"><a class="nav-link" href="demo/html/norc/index2.php">CONTACT</a></li>
                </ul>
            </div>
        </div>
    </nav>
  
    <a class="btn book-now desktop open-datepicker-popup" href="demo/html/norc/index4.html" title="Book Now" style="font-weight: 100px; background-color: #000080;">G <br>E<br>T<br> Q<br>U<br>O<br>T<br>E</a>
      <div class="scroller"></div>
    
    
    <!-- Slider -->
    <header class="header slider-fade">
        <div class="owl-carousel owl-theme">
            <!-- The opacity on the iage is made with "data-overlay-dark="number". You can change it using the numbers 0-9. -->
            <div class="text-left item bg-img" data-overlay-dark="4" data-background="demo/html/norc/images/b1.jpeg">
                <div class="v-middle caption">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-7">
                                <h4>Guaranteed High Quality</h4>
                                <h1>Welcome to Top Machineries</h1>
                                <p>Our 25 years working experience make a different construction building. Viverra tristique usto duis vitae diam neque nivamus estan the atin viverra nectow drana setlie.</p> <a href="demo/html/norc/services.php" class="button-primary">Our Products</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-left item bg-img" data-overlay-dark="4" data-background="demo/html/norc/images/b2.jpeg">
                <div class="v-middle caption">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-7">
                                <h4>Architecture Design</h4>
                                <h1>We Build Great Projects</h1>
                                <p>Our 25 years working experience make a different construction building. Viverra tristique usto duis vitae diam neque nivamus estan the atin viverra nectow drana setlie.</p> <a href="demo/html/norc/services.php" class="button-primary">Our Products</a> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-left item bg-img" data-overlay-dark="4" data-background="demo/html/norc/images/b3.jpeg">
                <div class="v-middle caption">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-7">
                                <h4>Professional Team</h4>
                                <h1>Build Your Dream House</h1>
                                <p>Our 25 years working experience make a different construction building. Viverra tristique usto duis vitae diam neque nivamus estan the atin viverra nectow drana setlie.</p> <a href="demo/html/norc/services.php" class="button-primary">Our Products</a> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    
        
    <!-- Services -->
    <section class="services center section-padding bg-gray">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-subtitle">What We Do</div>
                    <div class="section-title">Our <span>Services</span></div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 owl-carousel owl-theme">

                <?php
                    $products = mysqli_query($conn, "SELECT * FROM `industries` ORDER BY `id` DESC LIMIT 6  ");
                    while($row_pro  = mysqli_fetch_assoc($products)){
                                extract($row_pro) ;      
            ?>


                    <div class="item mb-30">
                        <div class="service-img">
                            <div class="img"> <img src="<?php   echo $industry_image; ?> " alt=""> </div>
                        </div>
                        <div class="cont">
                            <div class="service-icon"> <i class="norc-new-construction"></i> </div>
                            <h5>Project Planning</a></h5>
                            <p>Quisque imperdie miss sapien porttiton the bibendum. Pellentesque accumsa amet tincidunt risus nesuen.</p> <a href="demo/html/norc/about_company.php?user_id=<?php echo $row_pro['id']; ?>" class="link-btn" tabindex="0">View service</a>
                        </div>
                    </div>

            <?php } ?>
            
                    <!-- <div class="item mb-30">
                        <div class="service-img">
                            <div class="img"> <img src="demo/html/norc/images/our_ser1.jpeg" alt=""> </div>
                        </div>
                        <div class="cont">
                            <div class="service-icon"> <i class="norc-construction-sign"></i> </div>
                            <h5>General Contracting</h5>
                            <p>Quisque imperdie miss sapien porttiton the bibendum. Pellentesque accumsa amet tincidunt risus nesuen.</p> <a href="demo/html/norc/about_company.php" class="link-btn" tabindex="0">View service</a>
                        </div>
                    </div> -->
                    <!-- <div class="item mb-30">
                        <div class="service-img">
                            <div class="img"> <img src="demo/html/norc/images/our_ser.jpeg" alt=""> </div>
                        </div>
                        <div class="cont">
                            <div class="service-icon"> <i class="norc-factory"></i> </div>
                            <h5>Industrial / Manufacturing</h5>
                            <p>Quisque imperdie miss sapien porttiton the bibendum. Pellentesque accumsa amet tincidunt risus nesuen.</p> <a href="demo/html/norc/about_company.php" class="link-btn" tabindex="0">View service</a>
                        </div>
                    </div> -->
                    <!-- <div class="item mb-30">
                        <div class="service-img">
                            <div class="img"> <img src="demo/html/norc/images/our_ser3.jpeg" alt=""> </div>
                        </div>
                        <div class="cont">
                            <div class="service-icon"> <i class="norc-radiation"></i> </div>
                            <h5>Energy and Environment</h5>
                            <p>Quisque imperdie miss sapien porttiton the bibendum. Pellentesque accumsa amet tincidunt risus nesuen.</p> <a href="demo/html/norc/about_company.php" class="link-btn" tabindex="0">View service</a>
                        </div>
                    </div> -->
                    <!-- <div class="item mb-30">
                        <div class="service-img">
                            <div class="img"> <img src="demo/html/norc/images/our_ser.jpeg" alt=""> </div>
                        </div>
                        <div class="cont">
                            <div class="service-icon"> <i class="norc-cogwheel"></i> </div>
                            <h5>Const. Management</h5>
                            <p>Quisque imperdie miss sapien porttiton the bibendum. Pellentesque accumsa amet tincidunt risus nesuen.</p> <a href="demo/html/norc/about_company.php" class="link-btn" tabindex="0">View service</a>
                        </div>
                    </div> -->
                    <!-- <div class="item mb-30">
                        <div class="service-img">
                            <div class="img"> <img src="demo/html/norc/images/our_ser.jpeg" alt=""> </div>
                        </div>
                        <div class="cont">
                            <div class="service-icon"> <i class="norc-pantone"></i> </div>
                            <h5>Interior Design</h5>
                            <p>Quisque imperdie miss sapien porttiton the bibendum. Pellentesque accumsa amet tincidunt risus nesuen.</p> <a href="demo/html/norc/about_company.php" class="link-btn" tabindex="0">View service</a>
                        </div>
                    </div> -->
                </div>
            </div>
        </div>
    </section>
    <!-- Process -->
    <!-- <section class="process">
        <div class="section-padding bg-img bg-fixed section-padding" data-background="img/banner2.jpg" data-overlay-dark="6">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 offset-md-3 mb-45 text-center">
                        <h5>How We Work</h5>
                        <h2>Our Process</h2>
                        <p>Suspendisse potenti sed laoen ultra magna in dignissim justo porta miss acurabitur luctus magna numsation elentesue the miss vitae moie.</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3 padding">
                        <div class="item text-center"> <img src="demo/html/norc/img/arrow1.png" class="tobotm" alt=""> <span class="icon norc-paper"></span>
                            <h6><span>01.</span>Planing</h6>
                        </div>
                    </div>
                    <div class="col-md-3 padding">
                        <div class="item text-center"> <img src="demo/html/norc/img/arrow1.png" alt=""> <span class="icon norc-pen-tool-2"></span>
                            <h6><span>02.</span>Design</h6>
                        </div>
                    </div>
                    <div class="col-md-3 padding">
                        <div class="item text-center"> <img src="demo/html/norc/img/arrow1.png" class="tobotm" alt=""> <span class="icon norc-new-construction"></span>
                            <h6><span>03.</span>Construct</h6>
                        </div>
                    </div>
                    <div class="col-md-3 padding">
                        <div class="item text-center"> <span class="icon norc-trophy"></span>
                            <h6><span>04.</span>Finishing</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- Projects -->
    <section class="projects section-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-subtitle">Latest products</div>
                    <div class="section-title">Our <span>products</span></div>
                </div>
            </div>
            <div class="row">

            <?php
                $products = mysqli_query($conn, "SELECT * FROM `our_product` LIMIT 3 ");
                while($row_pro  = mysqli_fetch_assoc($products)){
                            extract($row_pro) ;      
            ?>

                <div class="col-md-12 mb-90">
                    <div class="projects left">
                        <figure><img src="images/<?php echo $ads_file; ?>" alt="" class="img-fluid"></figure>
                        <div class="caption">
                            <h4>Interior Remodeling <span>in Westport, CT</span></h4>
                            <p>Construction elibero tristique mattis suspen dissen potenti seden laorien ultricies magna, in dignissim justo porta eget miss vention ormana the miss drana on the tenis vitae mollie.</p>
                            <div class="line-dec"></div>
                            <div class="info-wrapper">
                                <div class="date"><i class="norc-new-construction"></i> <a href="images/files/<?php echo $ads_file2; ?>" download="files">Download</a></div>
                                <div class="more"><a href="demo/html/norc/services-page.php?user_id=<?php echo $row_pro['id']; ?>" class="link-btn" tabindex="0">Discover</a></div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php } ?>

              
            </div>
        </div>
    </section>
    <!-- Values -->
    <section class="values section-padding bg-gray">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-subtitle">Our Values</div>
                    <div class="section-title">Core <span>Values</span></div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="single-facility"> <span class="norc-construction-sign"></span>
                        <h5>Safety</h5>
                        <p>Safety will always come first as we strive for accident-free projects. Fusce tidunt nis ace park norttito amet space.</p>
                        <div class="facility-shape"> <span class="norc-construction-sign"></span> </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="single-facility"> <span class="norc-bulb-63"></span>
                        <h5>Garantee</h5>
                        <p>Nulla quis effi vivento acus suvina sene in atue eduis euro vesatien arcum the onte nisl auctor a menas vitae.</p>
                        <div class="facility-shape"> <span class="norc-bulb-63"></span> </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="single-facility"> <span class="norc-paper-diploma"></span>
                        <h5>Quality</h5>
                        <p>Nulla quis effi vivento acus suvina sene in atue eduis euro vesatien arcum the onte nisl auctor a menas vitae.</p>
                        <div class="facility-shape"> <span class="norc-paper-diploma"></span> </div>
                    </div>
                </div>
              
            </div>
        </div>
    </section>
    <!-- Team -->
    <!-- <section class="team section-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-subtitle">Expert Worker</div>
                    <div class="section-title">Meet <span>Our Team</span></div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 owl-carousel owl-theme">
                    <div class="team-card mb-30">
                        <div class="team-img"><img src="demo/html/norc/img/team/1.jpg" alt="" class="w-100"></div>
                        <div class="team-content">
                            <h3 class="team-title">Adam Norman<span>CEO & Founder</span></h3>
                            <p class="team-text">Nulla quis efficitur lacus sulvinar suere ausue in eduis euro vesatien arcuman ontese auctor ac aleuam aretra.</p>
                            <div class="social">
                                <div class="full-width"> <a href="#"><i class="fa fa-linkedin"></i></a> <a href="#"><i class="fa fa-facebook"></i></a> <a href="#"><i class="fa fa-twitter"></i></a> <a href="#"><i class="fa fa-instagram"></i></a> </div>
                            </div>
                        </div>
                        <div class="title-box">
                            <h3 class="mb-0">Adam Norman<span>CEO & Founder</span></h3>
                        </div>
                    </div>
                    <div class="team-card mb-30">
                        <div class="team-img"><img src="demo/html/norc/img/team/6.jpg" alt="" class="w-100"></div>
                        <div class="team-content">
                            <h3 class="team-title">Enrico Brown<span>Head of Sales</span></h3>
                            <p class="team-text">Nulla quis efficitur lacus sulvinar suere ausue in eduis euro vesatien arcuman ontese auctor ac aleuam aretra.</p>
                            <div class="social">
                                <div class="full-width"> <a href="#"><i class="fa fa-linkedin"></i></a> <a href="#"><i class="fa fa-facebook"></i></a> <a href="#"><i class="fa fa-twitter"></i></a> <a href="#"><i class="fa fa-instagram"></i></a> </div>
                            </div>
                        </div>
                        <div class="title-box">
                            <h3 class="mb-0">Enrico Brown<span>Head of Sales</span></h3>
                        </div>
                    </div>
                    <div class="team-card mb-30">
                        <div class="team-img"><img src="demo/html/norc/img/team/5.jpg" alt="" class="w-100"></div>
                        <div class="team-content">
                            <h3 class="team-title">John Snow<span>Lead Project Manager</span></h3>
                            <p class="team-text">Nulla quis efficitur lacus sulvinar suere ausue in eduis euro vesatien arcuman ontese auctor ac aleuam aretra.</p>
                            <div class="social">
                                <div class="full-width"> <a href="#"><i class="fa fa-linkedin"></i></a> <a href="#"><i class="fa fa-facebook"></i></a> <a href="#"><i class="fa fa-twitter"></i></a> <a href="#"><i class="fa fa-instagram"></i></a> </div>
                            </div>
                        </div>
                        <div class="title-box">
                            <h3 class="mb-0">John Snow<span>Lead Project Manager</span></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- Numbers -->
    <!-- <section class="numbers">
        <div class="section-padding bg-img bg-fixed section-padding" data-background="img/banner2.jpg" data-overlay-dark="6">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <div class="item text-center"> <span class="icon">
                                <i class="front norc-design"></i>
                                <i class="back norc-design"></i>
                            </span>
                            <h3 class="count">675</h3>
                            <h6><span>01.</span> Projects Design</h6>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="item text-center"> <span class="icon">
                                <i class="font norc-b-meeting"></i>
                                <i class="back norc-b-meeting"></i>
                            </span>
                            <h3 class="count">450</h3>
                            <h6><span>02.</span> Happy Clients</h6>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="item text-center"> <span class="icon">
                                <i class="front norc-paper-diploma"></i>
                                <i class="back norc-paper-diploma"></i>
                            </span>
                            <h3 class="count">550</h3>
                            <h6><span>03.</span> Completed Projects</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- News -->
    <section class="services center section-padding bg-gray">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-subtitle">Available</div>
                <div class="section-title">Other <span>Products</span></div>
            </div>
        </div>
        <div class="row">

            <div class="col-md-12 owl-carousel owl-theme">

            <?php
                $products = mysqli_query($conn, "SELECT * FROM `our_product` LIMIT 5 ");
                while($row_pro  = mysqli_fetch_assoc($products)){
                            extract($row_pro) ;      
            ?>

                <div class="item mb-30">
                    <div class="service-img">
                        <div class="img"> <img src="/machineries/images/<?php echo $ads_file; ?>" alt=""> </div>
                    </div>
                    <div class="cont">
                        <div class="service-icon"> <i class="norc-construction-sign"></i> </div>
                        <h5><?php echo $machine_name;  ?></h5>
                        <p><?php echo $short_details;  ?></p> <a href="demo/html/norc/services-page.php?user_id=<?php echo $row_pro['id']; ?>" class="link-btn" tabindex="0">View service</a>
                    </div>
                </div>

            <?php } ?>

                <!-- <div class="item mb-30">
                    <div class="service-img">
                        <div class="img"> <img src="../../../demo/html/norc/img/P10.jpeg" alt=""> </div>
                    </div>
                    <div class="cont">
                        <div class="service-icon"> <i class="norc-factory"></i> </div>
                        <h5><a href="../../../demo/html/norc/services-page.html">Industrial / Manufacturing</a></h5>
                        <p>Quisque imperdie miss sapien porttiton the bibendum. Pellentesque accumsa amet tincidunt risus nesuen.</p> <a href="../../../demo/html/norc/services-page.html" class="link-btn" tabindex="0">View service</a>
                    </div>
                </div> -->
                <!-- <div class="item mb-30">
                    <div class="service-img">
                        <div class="img"> <img src="../../../demo/html/norc/img/P12.jpeg" alt=""> </div>
                    </div>
                    <div class="cont">
                        <div class="service-icon"> <i class="norc-radiation"></i> </div>
                        <h5><a href="../../../demo/html/norc/services-page.html">Energy and Environment</a></h5>
                        <p>Quisque imperdie miss sapien porttiton the bibendum. Pellentesque accumsa amet tincidunt risus nesuen.</p> <a href="../../../demo/html/norc/services-page.html" class="link-btn" tabindex="0">View service</a>
                    </div>
                </div> -->
                <!-- <div class="item mb-30">
                    <div class="service-img">
                        <div class="img"> <img src="../../../demo/html/norc/img/P14.jpeg" alt=""> </div>
                    </div>
                    <div class="cont">
                        <div class="service-icon"> <i class="norc-cogwheel"></i> </div>
                        <h5><a href="../../../demo/html/norc/services-page.html">Const. Management</a></h5>
                        <p>Quisque imperdie miss sapien porttiton the bibendum. Pellentesque accumsa amet tincidunt risus nesuen.</p> <a href="../../../demo/html/norc/services-page.html" class="link-btn" tabindex="0">View service</a>
                    </div>
                </div> -->
                <!-- <div class="item mb-30">
                    <div class="service-img">
                        <div class="img"> <img src="../../../demo/html/norc/img/P16.jpeg" alt=""> </div>
                    </div>
                    <div class="cont">
                        <div class="service-icon"> <i class="norc-pantone"></i> </div>
                        <h5><a href="../../../demo/html/norc/services-page.html">Interior Design</a></h5>
                        <p>Quisque imperdie miss sapien porttiton the bibendum. Pellentesque accumsa amet tincidunt risus nesuen.</p> <a href="../../../demo/html/norc/services-page.html" class="link-btn" tabindex="0">View service</a>
                    </div>
                </div> -->
            </div>
        </div>
    </div>
</section>
    <!-- Video & Testiominals -->
    <section class="testimonials">
        <div class="background bg-img bg-fixed section-padding pb-0" data-background="img/banner.jpg" data-overlay-dark="4">
            <div class="container">
                <div class="row">
                    <!-- Video -->
                    <div class="col-md-6 mb-30 valign">
                        <div class="vid-area">
                            <div class="vid-icon">
                                <a class="play-button vid" href="https://youtu.be/z4nO6NuEM3A">
                                    <svg class="circle-fill">
                                        <circle cx="43" cy="43" r="39" stroke="#fff" stroke-width="1"></circle>
                                    </svg>
                                    <svg class="circle-track">
                                        <circle cx="43" cy="43" r="39" stroke="none" stroke-width="1" fill="none"></circle>
                                    </svg> <span class="polygon">
                                        <i class="norc-triangle-right"></i>
                                    </span> </a>
                            </div>
                            <div class="cont mt-30 mb-30">
                                <h6>Promo Video</h6>
                                <h4>Video About Company</h4>
                                <p>Video showing our 25 years of business experience.</p>
                            </div>
                        </div>
                    </div>
                    <!-- Testiominals -->
                    <div class="col-md-5 offset-md-1">
                        <div class="testimonials-box">
                            <div class="head-box">
                                <h6>What said about us</h6>
                                <h4>Customer Reviews</h4>
                            </div>
                            <div class="owl-carousel owl-theme">
                                <div class="item"> <span class="quote"><img src="demo/html/norc/img/quot.png" alt=""></span>
                                    <p class="v-border">Company kaya nisl ullamcorper the duru metu enna lophare mavna busnini viventa the ornare ipsuma. Curabitur magna pentesue the miss tenis vitae.</p>
                                    <div class="info">
                                        <div class="author-img"> <img src="demo/html/norc/img/team/comment2.jpg" alt=""> </div>
                                        <div class="cont">
                                            <h6>Jason Brown</h6> <span>Hollywood Hills, CA</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="item"> <span class="quote">
                                        <img src="demo/html/norc/img/quot.png" alt="">
                                    </span>
                                    <p class="v-border">Company kaya nisl ullamcorper the duru metu enna lophare mavna busnini viventa the ornare ipsuma. Curabitur magna pentesue the miss tenis vitae.</p>
                                    <div class="info">
                                        <div class="author-img"> <img src="demo/html/norc/img/team/comment3.jpg" alt=""> </div>
                                        <div class="cont">
                                            <h6>Emily White</h6> <span>Los Angeles, CA</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="item"> <span class="quote">
                                        <img src="demo/html/norc/img/quot.png" alt="">
                                    </span>
                                    <p class="v-border">Company kaya nisl ullamcorper the duru metu enna lophare mavna busnini viventa the ornare ipsuma. Curabitur magna pentesue the miss tenis vitae.</p>
                                    <div class="info">
                                        <div class="author-img"> <img src="demo/html/norc/img/team/comment.jpg" alt=""> </div>
                                        <div class="cont">
                                            <h6>Enrico Smith</h6> <span>Malibu Beach, CA</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Clients -->
    <section class="clients">
        <div class="container">
            <div class="row">
                <div class="col-md-7">
                    <div class="owl-carousel owl-theme">
                        <div class="clients-logo">
                            <a href="#0"><img src="demo/html/norc/img/clients/1.png" alt=""></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="demo/html/norc/img/clients/2.png" alt=""></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="demo/html/norc/img/clients/3.png" alt=""></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="demo/html/norc/img/clients/4.png" alt=""></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="demo/html/norc/img/clients/5.png" alt=""></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="demo/html/norc/img/clients/6.png" alt=""></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-5"></div>
            </div>
        </div>
    </section>
    <!-- Footer -->
    <footer class="footer clearfix">
        <div class="container">
            <!-- First footer -->
            <div class="first-footer">
                <div class="row">
                    <div class="col-md-12">
                        <div class="links dark footer-contact-links">
                            <div class="footer-contact-links-wrapper">
                                <div class="footer-contact-link-wrapper">
                                    <div class="image-wrapper footer-contact-link-icon">
                                        <div class="icon-footer"> <i class="norc-phone"></i> </div>
                                    </div>
                                    <div class="footer-contact-link-content">
                                        <h6>Call us</h6>
                                        <p>+1 203-333-4444</p>
                                    </div>
                                </div>
                                <div class="footer-contact-links-divider"></div>
                                <div class="footer-contact-link-wrapper">
                                    <div class="image-wrapper footer-contact-link-icon">
                                        <div class="icon-footer"> <i class="norc-mail"></i> </div>
                                    </div>
                                    <div class="footer-contact-link-content">
                                        <h6>Write to us</h6>
                                        <p>info@construction.com</p>
                                    </div>
                                </div>
                                <div class="footer-contact-links-divider"></div>
                                <div class="footer-contact-link-wrapper">
                                    <div class="image-wrapper footer-contact-link-icon">
                                        <div class="icon-footer"> <i class="norc-property-location"></i> </div>
                                    </div>
                                    <div class="footer-contact-link-content">
                                        <h6>Address</h6>
                                        <p>24 King St, SC 29401 USA</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Second footer -->
            <div class="second-footer">
                <div class="row">
                    <!-- about & social icons -->
                    <div class="col-md-4 widget-area">
                        <div class="widget clearfix">
                            <h3 class="widget-title">About Norc.</h3>
                            <div class="widget-text">
                                <p>Quisque imperdiet sapien porttito the bibendum sellentesque the commodo erat acar accumsa lobortis, enim diam the nesuen.</p>
                                <div class="social-icons">
                                    <ul class="list-inline">
                                        <li><a href="#"><i class="fa fa-whatsapp"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                        <li><a href="#"><i class="fa fa-youtube-play"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- quick links -->
                    <div class="col-md-3 offset-md-1 widget-area">
                        <div class="widget clearfix usful-links">
                            <h3 class="widget-title">Quick Links</h3>
                            <ul>
                                <li><a href="indexx.html">HOME</a></li>
                                <li><a href="demo/html/norc/about.php">ABOUT US</a></li>
                                <li><a href="demo/html/norc/services.php">PRODUCTS </a></li>
                                <li><a href="demo/html/norc/services2.php">INDUSTRIES</a></li>
                                <!-- <li><a href="demo/html/norc/blog.html">SUPPORT</a></li> -->
                                <li><a href="demo/html/norc/services3.php">NEWS</a></li>
                                <li><a href="demo/html/norc/index2.html">CONTACT</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- subscribe -->
                    <div class="col-md-4 widget-area">
                        <div class="widget clearfix">
                            <h3 class="widget-title">Subscribe</h3>
                            <p>Want to be notified about our news. Just sign up and we'll send you a notification by email.</p>
                            <div class="widget-newsletter">
                                <form method="POST" action="footer.php">
                                    <p style="color: red; text-align: center;"> <?PHP if (isset($error)){echo $error;} ?></p>
                                    <input type="email" name="subcription" placeholder="Email Address" required>
                                    <button name="submit" type="submit">Send</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Bottom footer -->
            <div class="bottom-footer-text">
                <div class="row copyright">
                    <div class="col-md-12">
                        <p style="text-align: center;" class="mb-0">©2022 <a href="#">topmachineries</a>. All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- jQuery -->
    <script src="demo/html/norc/js/jquery-3.6.0.min.js"></script>
    <script src="demo/html/norc/js/jquery-migrate-3.0.0.min.js"></script>
    <script src="demo/html/norc/js/modernizr-2.6.2.min.js"></script>
    <script src="demo/html/norc/js/imagesloaded.pkgd.min.js"></script>
    <script src="demo/html/norc/js/jquery.isotope.v3.0.2.js"></script>
    <script src="demo/html/norc/js/popper.min.js"></script>
    <script src="demo/html/norc/js/bootstrap.min.js"></script>
    <script src="demo/html/norc/js/scrollIt.min.js"></script>
    <script src="demo/html/norc/js/jquery.waypoints.min.js"></script>
    <script src="demo/html/norc/js/owl.carousel.min.js"></script>
    <script src="demo/html/norc/js/jquery.stellar.min.js"></script>
    <script src="demo/html/norc/js/jquery.magnific-popup.js"></script>
    <script src="demo/html/norc/js/jquery.counterup.min.js"></script>
    <script src="demo/html/norc/js/YouTubePopUp.js"></script>
    <script src="demo/html/norc/js/custom.js"></script>
<!-- <center><font size="2">This is the free demo result. For a full version of this website, please go to  <a href="https://www6.waybackmachinedownloader.com/website-downloader-online/scrape-all-files/">Website Downloader</a></font></center></body> -->
</html>