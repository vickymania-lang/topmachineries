<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Mix And Shake By Beeba</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


    <link href="https://fonts.googleapis.com/css?family=Oswald:400,700|Work+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo $DOT;?>fonts/icomoon/style.css">
    <link rel="stylesheet" href="<?php echo $DOT;?>css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $DOT;?>css/magnific-popup.css">
    <link rel="stylesheet" href="<?php echo $DOT;?>css/jquery-ui.css">
    <link rel="stylesheet" href="<?php echo $DOT;?>css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo $DOT;?>css/owl.theme.default.min.css">
    <link rel="stylesheet" href="<?php echo $DOT;?>css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="<?php echo $DOT;?>css/animate.css">    
    <link rel="stylesheet" href="<?php echo $DOT;?>fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="<?php echo $DOT;?>css/aos.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap4.min.css">
    
    <link rel="stylesheet" href="<?php echo $DOT;?>css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="http://maxcdn.icons8.com/fonts/line-awesome/css/line-awesome.min.css" rel="stylesheet" type="text/css"/>
    
  </head>
  <body oncontextmenu="return false;">


  <div class="site-wrap">

      <nav class="navbar navbar-expand-md navbar-light bg-light fixed-top">
          <a class="navbar-brand" href="<?php echo $DOT;?>">Mix and Shakes by Beeba</a>
          <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarsExample03" aria-controls="navbarsExample03" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
    
          <div class="navbar-collapse collapse" id="navbarsExample03" style="">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item <?php if ($page=="home") {echo "active"; } else  {echo "noactive";}?>">
                <a class="nav-link" href="<?php echo $DOT;?>">HOME&nbsp;&nbsp;</a>
              </li>
              <li class="nav-item <?php if ($page=="services") {echo "active"; } else  {echo "noactive";}?>">
                <a class="nav-link" href="<?php echo $DOT;?>services/">SERVICES&nbsp;&nbsp;</a>
              </li>
              <li class="nav-item <?php if ($page=="blog") {echo "active"; } else  {echo "noactive";}?>">
                <a class="nav-link" href="<?php echo $DOT;?>blog/">RECIPES&nbsp;&nbsp;</a>
              </li>
              <li class="nav-item <?php if ($page=="training") {echo "active"; } else  {echo "noactive";}?>">
                <a class="nav-link" href="<?php echo $DOT;?>training/">TRAINING&nbsp;&nbsp;</a>
              </li>
              <li class="nav-item <?php if ($page=="ebook") {echo "active"; } else  {echo "noactive";}?>">
                <a class="nav-link" href="<?php echo $DOT;?>ebooks/">E-BOOKS&nbsp;&nbsp;</a>
              </li>
              <li class="nav-item <?php if ($page=="contact") {echo "active"; } else  {echo "noactive";}?>">
                <a class="nav-link" href="<?php echo $DOT;?>contact/">CONTACT &nbsp;&nbsp;</a>
              </li>
              <li class="nav-item <?php if ($page=="dashboard") {echo "active"; } else  {echo "noactive";}?>">
                <a class="nav-link" href="<?php echo $DOT;?>dashboard/">DASHBOARD &nbsp;&nbsp;</a>
              </li>
              <li class="nav-item  <?php if ($page=="logout") {echo "active"; } else  {echo "noactive";}?>">
                <a class="nav-link btn btn-primary text-white" href="<?php echo $DOT;?>logout.php">LOGOUT</a>
              </li>
            </ul>
          </div>
        </nav>