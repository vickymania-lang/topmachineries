<?php
$DOT = "../";
$page = "about";
include_once($DOT . 'header.php');
?>
<!-- Header Banner -->
<!-- The opacity on the image is made with "data-overlay-dark="number". You can change it using the numbers 0-9. -->
<section class="banner-header banner-img-top section-padding valign bg-img bg-fixed" data-overlay-dark="4" data-background="<?php echo $DOT;?>img/slider/1.jpg">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <h6>Construction Firm</h6>
                <h1>About <span>Top Machineries</span></h1>
            </div>
        </div>
    </div>
</section>
<!-- About -->
<section class="about section-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-6 mb-30">
                <h5>Leading Way In Building & Civil Construction!</h5>
                <p>Our company at libero tristique mattis. Suspendisse potenti sed leonra main dignissim justo porta eget. Curabitur luctus magna numsaton vivention esellentesue the miss tenis vitae mollie.</p>
                <p>Curabitur luctus magna numsaton vivention esellentesue the mis awa vitao sedeonra manain dignissim porta. Suspendisse potention sedeonrate main dignissim justo porta eget. </p>
                <ul class="listext list-unstyled mb-30">
                    <li>
                        <div class="listext-icon"> <i class="norc-d-check"></i> </div>
                        <div class="listext-text">
                            <p>Over 25 years of experience</p>
                        </div>
                    </li>
                    <li>
                        <div class="listext-icon"> <i class="norc-d-check"></i> </div>
                        <div class="listext-text">
                            <p>100+ successfully executed projects</p>
                        </div>
                    </li>
                    <li>
                        <div class="listext-icon"> <i class="norc-d-check"></i> </div>
                        <div class="listext-text">
                            <p>Exceptional work quality</p>
                        </div>
                    </li>
                </ul>
                <div class="line-dec"></div>
                <div class="about-bottom"> <img src="<?php echo $DOT;?>img/signature-dark.svg" alt="" class="image about-signature">
                    <div class="about-name-wrapper">
                        <div class="about-name">Samuel Ibeobi</div>
                        <div class="about-rol">CEO & Founder</div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="about-img fl-wrap">
                    <img src="<?php echo $DOT;?>img/about4.jpg" class="img-fluid" alt="">
                    <div class="about-img-hotifer color-bg">
                        <p>Our 25 years working experience make a different construction building.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- About Info -->
<section class="about-info section-padding bg-gray">
    <div class="container">
        <div class="about-info">
            <div class="row">
                <div class="col-md-5">
                    <div class="about-info-img mb-60">
                        <div class="img"> <img src="<?php echo $DOT;?>img/about2.jpg" class="img-fluid" alt=""> </div>
                    </div>
                    <div class="section-title2">The story of how <span>norc company</span> was founded</div>
                    <p>Build quis efficitur lacus sulvinar posuere augue eduis euro vesatien arcuman onteger leo nisl auctor ac aliquam asus nuis risus maecenas vitae tellus massa aselus.</p>
                </div>
                <div class="col-md-6 offset-md-1 pt-60">
                    <div class="section-title2">Leading Way In <span>Building & Civil Construction!</span></div>
                    <p>Nulla quis efficitur lacus sulvinar posuere augue eduis euro vesatien arcuman onteger leo nisl auctor ac aliquam a placerat quis risus maecenas vitae tellus massa aselus faucibu in haretra.</p>
                    <div class="about-info-img pt-60">
                        <div class="img"> <img src="<?php echo $DOT;?>img/about3.jpg" class="img-fluid" alt=""> </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Team -->
<section class="team section-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-subtitle">Expert Worker</div>
                <div class="section-title">Meet <span>Our Team</span></div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="team-card mb-30">
                    <div class="team-img"><img src="<?php echo $DOT;?>img/team/1.jpg" alt="" class="w-100"></div>
                    <div class="team-content">
                        <h3 class="team-title">Samuel Ibeobi<span>CEO & Founder</span></h3>
                        <p class="team-text">Nulla quis efficitur lacus sulvinar suere ausue in eduis euro vesatien arcuman ontese auctor ac aleuam aretra.</p>
                        <div class="social">
                            <div class="full-width">
                                <a href="#"><i class="fa fa-linkedin"></i></a>
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="title-box">
                        <h3 class="mb-0">Samuel Ibeobi<span>CEO & Founder</span></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="team-card mb-30">
                    <div class="team-img"><img src="<?php echo $DOT;?>img/team/2.jpg" alt="" class="w-100"></div>
                    <div class="team-content">
                        <h3 class="team-title">Enrico Brown<span>Head of Sales</span></h3>
                        <p class="team-text">Nulla quis efficitur lacus sulvinar suere ausue in eduis euro vesatien arcuman ontese auctor ac aleuam aretra.</p>
                        <div class="social">
                            <div class="full-width">
                                <a href="#"><i class="fa fa-linkedin"></i></a>
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="title-box">
                        <h3 class="mb-0">Enrico Brown<span>Head of Sales</span></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="team-card mb-30">
                    <div class="team-img"><img src="<?php echo $DOT;?>img/team/3.jpg" alt="" class="w-100"></div>
                    <div class="team-content">
                        <h3 class="team-title">Olivia White<span>Lead Project Manager</span></h3>
                        <p class="team-text">Nulla quis efficitur lacus sulvinar suere ausue in eduis euro vesatien arcuman ontese auctor ac aleuam aretra.</p>
                        <div class="social">
                            <div class="full-width">
                                <a href="#"><i class="fa fa-linkedin"></i></a>
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="title-box">
                        <h3 class="mb-0">Olivia White<span>Lead Project Manager</span></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Numbers -->
<section class="numbers">
    <div class="section-padding bg-img bg-fixed section-padding" data-background="<?php echo $DOT;?>img/banner2.jpg" data-overlay-dark="6">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="item text-center">
                        <span class="icon">
                            <i class="front norc-design"></i>
                            <i class="back norc-design"></i>
                        </span>
                        <h3 class="count">675</h3>
                        <h6><span>01.</span> Projects Design</h6>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="item text-center">
                        <span class="icon">
                            <i class="font norc-b-meeting"></i>
                            <i class="back norc-b-meeting"></i>
                        </span>
                        <h3 class="count">450</h3>
                        <h6><span>02.</span> Happy Clients</h6>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="item text-center">
                        <span class="icon">
                            <i class="front norc-paper-diploma"></i>
                            <i class="back norc-paper-diploma"></i>
                        </span>
                        <h3 class="count">550</h3>
                        <h6><span>03.</span> Completed Projects</h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Values -->
<section class="values section-padding bg-gray">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-subtitle">Our Values</div>
                <div class="section-title">Core <span>Values</span></div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="single-facility">
                    <span class="norc-construction-sign"></span>
                    <h5>Safety</h5>
                    <p>Safety will always come first as we strive for accident-free projects. Fusce tincidunt nis ace park norttito amet space.</p>
                    <div class="facility-shape"> <span class="norc-construction-sign"></span> </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="single-facility">
                    <span class="norc-bulb-63"></span>
                    <h5>Innovation</h5>
                    <p>Nulla quis effi vivento acus suvina sene in atue eduis euro vesatien arcum the onte nisl auctor a menas vitae.</p>
                    <div class="facility-shape"> <span class="norc-bulb-63"></span> </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="single-facility">
                    <span class="norc-paper-diploma"></span>
                    <h5>Quality</h5>
                    <p>Nulla quis effi vivento acus suvina sene in atue eduis euro vesatien arcum the onte nisl auctor a menas vitae.</p>
                    <div class="facility-shape"> <span class="norc-paper-diploma"></span> </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="single-facility">
                    <span class="norc-chess-knight"></span>
                    <h5>Integrity</h5>
                    <p>Nulla quis effi vivento acus suvina sene in atue eduis euro vesatien arcum the onte nisl auctor a menas vitae.</p>
                    <div class="facility-shape"> <span class="norc-chess-knight"></span> </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="single-facility">
                    <span class="norc-strategy"></span>
                    <h5>Strategy</h5>
                    <p>Nulla quis effi vivento acus suvina sene in atue eduis euro vesatien arcum the onte nisl auctor a menas vitae.</p>
                    <div class="facility-shape"> <span class="norc-strategy"></span> </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="single-facility">
                    <span class="norc-flag-points-32"></span>
                    <h5>Inclusion</h5>
                    <p>Nulla quis effi vivento acus suvina sene in atue eduis euro vesatien arcum the onte nisl auctor a menas vitae.</p>
                    <div class="facility-shape"> <span class="norc-flag-points-32"></span> </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Video & Testiominals -->
<section class="testimonials">
    <div class="background bg-img bg-fixed section-padding pb-0" data-background="<?php echo $DOT;?>img/banner.jpg" data-overlay-dark="4">
        <div class="container">
            <div class="row">
                <!-- Video -->
                <div class="col-md-6 mb-30 valign">
                    <div class="vid-area">
                        <div class="vid-icon">
                            <a class="play-button vid" href="https://youtu.be/z4nO6NuEM3A">
                                <svg class="circle-fill">
                                    <circle cx="43" cy="43" r="39" stroke="#fff" stroke-width="1"></circle>
                                </svg>
                                <svg class="circle-track">
                                    <circle cx="43" cy="43" r="39" stroke="none" stroke-width="1" fill="none"></circle>
                                </svg> <span class="polygon">
                                    <i class="norc-triangle-right"></i>
                                </span> </a>
                        </div>
                        <div class="cont mt-30 mb-30">
                            <h6>Promo Video</h6>
                            <h4>Video About Company</h4>
                            <p>Video showing our 25 years of business experience.</p>
                        </div>
                    </div>
                </div>
                <!-- Testiominals -->
                <div class="col-md-5 offset-md-1">
                    <div class="testimonials-box">
                        <div class="head-box">
                            <h6>What said about us</h6>
                            <h4>Customer Reviews</h4>
                        </div>
                        <div class="owl-carousel owl-theme">
                            <div class="item"> <span class="quote"><img src="<?php echo $DOT;?>img/quot.png" alt=""></span>
                                <p class="v-border">Company kaya nisl ullamcorper the duru metu enna lophare mavna busnini viventa the ornare ipsuma. Curabitur magna pentesue the miss tenis vitae.</p>
                                <div class="info">
                                    <div class="author-img"> <img src="<?php echo $DOT;?>img/team/comment2.jpg" alt=""> </div>
                                    <div class="cont">
                                        <h6>Jason Brown</h6> <span>Hollywood Hills, CA</span>
                                    </div>
                                </div>
                            </div>
                            <div class="item"> <span class="quote">
                                    <img src="<?php echo $DOT;?>img/quot.png" alt="">
                                </span>
                                <p class="v-border">Company kaya nisl ullamcorper the duru metu enna lophare mavna busnini viventa the ornare ipsuma. Curabitur magna pentesue the miss tenis vitae.</p>
                                <div class="info">
                                    <div class="author-img"> <img src="<?php echo $DOT;?>img/team/comment3.jpg" alt=""> </div>
                                    <div class="cont">
                                        <h6>Emily White</h6> <span>Los Angeles, CA</span>
                                    </div>
                                </div>
                            </div>
                            <div class="item"> <span class="quote">
                                    <img src="<?php echo $DOT;?>img/quot.png" alt="">
                                </span>
                                <p class="v-border">Company kaya nisl ullamcorper the duru metu enna lophare mavna busnini viventa the ornare ipsuma. Curabitur magna pentesue the miss tenis vitae.</p>
                                <div class="info">
                                    <div class="author-img"> <img src="<?php echo $DOT;?>img/team/comment.jpg" alt=""> </div>
                                    <div class="cont">
                                        <h6>Enrico Smith</h6> <span>Malibu Beach, CA</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Clients -->
<section class="clients">
    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <div class="owl-carousel owl-theme">
                    <div class="clients-logo">
                        <a href="#0"><img src="<?php echo $DOT;?>img/clients/1.png" alt=""></a>
                    </div>
                    <div class="clients-logo">
                        <a href="#0"><img src="<?php echo $DOT;?>img/clients/2.png" alt=""></a>
                    </div>
                    <div class="clients-logo">
                        <a href="#0"><img src="<?php echo $DOT;?>img/clients/3.png" alt=""></a>
                    </div>
                    <div class="clients-logo">
                        <a href="#0"><img src="<?php echo $DOT;?>img/clients/4.png" alt=""></a>
                    </div>
                    <div class="clients-logo">
                        <a href="#0"><img src="<?php echo $DOT;?>img/clients/5.png" alt=""></a>
                    </div>
                    <div class="clients-logo">
                        <a href="#0"><img src="<?php echo $DOT;?>img/clients/6.png" alt=""></a>
                    </div>
                </div>
            </div>
            <div class="col-md-5"></div>
        </div>
    </div>
</section>

<?php
include_once($DOT . 'footer.php');
?>