<?php


if(!empty($_POST['submit'])) {
    $subcription = $_POST['subcription'];

    if (empty($subcription)) {
        $error = 'gmail is empty';
    }
}

if(isset($_POST['submit'])){

    $to = "ogungbuyivictor@gmail.com.com";
    $subject = "Subcribe";
    $text = "I want to subcribe for notification with  $subcription";
    $headers = "From: $subcription";

}
 
if(mail($to, $subject, $txt, $headers)) {
    echo "Thanks for subcription.";

}else {
    echo "message not send";
}
;









?>