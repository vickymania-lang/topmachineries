<?php
$DOT = "../";
$page = "products";
//require_once $DOT.'session.php';
require_once $DOT . 'constants.php';
$products = $db->getProducts();
include_once($DOT . 'header.php');

?>
<!-- Services -->
<section class="services center section-padding bg-gray">
    <div class="container">

        <div class="row">
            <?php
            foreach ($products as $product) {

                echo '<div class="col-lg-3 col-md-6  col-sm-12"> <div class="item mb-30">
                            <div class="service-img">
                                <div class="img"> <img src="http:' . $product['image'] . '" alt=""> </div>
                            </div>
                            <div class="cont">
                                <div class="service-icon"><span style="font-size:1.3rem;"> $' . $product['price'] . '</span> </div>
                                
                                <p>' . $product['title'] . '</p> <a href="#" class="link-btn" tabindex="0">Add To Cart</a>
                            </div>
                        </div> </div>';
            }
            ?>
        </div>
    </div>
</section>


<?php
include_once($DOT . 'footer.php');
?>